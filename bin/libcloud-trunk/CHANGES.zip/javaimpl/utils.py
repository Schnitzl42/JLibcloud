
def none_check(att, default):
    '''
    Returns the given attribute if != None
    else the default value is returned
    '''
    return att if att != None else default

def wrap_listing(listing, clazz):
    '''
    wraps the given listing into a list
    containing the given class
    '''
    listt = []
    for entry in listing:
        listt.append(clazz(entry))
    return listt

def read_from_jar(relative_path):
    '''
    reads a file from within a jar. returns the file content
    '''
    from java.lang import ClassLoader
    from java.io import InputStreamReader, BufferedReader

    loader = ClassLoader.getSystemClassLoader()
    stream = loader.getResourceAsStream(relative_path)
    reader = BufferedReader(InputStreamReader(stream))
    
    line = reader.readLine()
    buf = ''
    while line is not None:
        buf += line
        line = reader.readLine()
        
    reader.close()
    stream.close()
    return buf