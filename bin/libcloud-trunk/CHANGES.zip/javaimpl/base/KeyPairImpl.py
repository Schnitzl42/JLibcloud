'''
Created on 07.01.2014

@author: root
'''
from jlibcloud.wrapperInterfaces.base import KeyPair as JKeyPair

from javaimpl.utils import none_check

class KeyPairImpl(JKeyPair):
    '''
    classdocs
    '''


    def __init__(self, key_pair):
        '''
        Constructor
        '''
        self.key_pair = key_pair
        from libcloud.compute.base import KeyPair
        if isinstance(key_pair, KeyPair):
            self.namep = none_check(key_pair.name, "")
            self.fingerprintp = none_check(key_pair.fingerprint, "")
            self.public_keyp = none_check(key_pair.public_key, "")
            self.private_keyp = none_check(key_pair.private_key, "")
            self.extrap = key_pair.extra
            self.repr = key_pair.__repr__()
        else:
            self.namep = ""
            self.fingerprintp = ""
            self.public_keyp = ""
            self.private_keyp = ""
            self.extrap = {}
            self.repr = ""
            
    def getName(self):
        return self.namep
    
    def getFingerprint(self):
        return self.fingerprintp
    
    def getPublicKey(self):
        return self.public_keyp
    
    def getPrivateKey(self):
        return self.private_keyp
    
    def getExtra(self):
        return self.extrap
    
    def toString(self):
        return self.repr
            
    