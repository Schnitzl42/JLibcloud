'''
Created on 11.12.2013

@author: root
'''
from jlibcloud.wrapperInterfaces.base import Node as JNode

from javaimpl.utils import none_check

class NodeImpl(JNode):
    """
    Represents a node.
    """
    def __init__(self, node):
        """
        :param node: an existing node
        :type node: :class:``libcloud.compute.base.Node``
        """
        self.node = node
        if hasattr(node, 'uuid'):
            self.uuidp = none_check(node.uuid, "")
        else:
            self.uuidp = ""
        if hasattr(node, 'id'):
            self.idp = none_check(node.id, "")
        else:
            self.idp = ""
        if hasattr(node, 'name'):
            self.namep = none_check(node.name, "")
        else:
            self.namep = ""
        if hasattr(node, 'extra'):
            self.extrap = node.extra
        else:
            self.extrap = {}  
        if hasattr(node, '__repr__()'):
            self.reprp = node.__repr__()
        else:
            self.reprp = ""  
            
        from libcloud.compute.base import Node
        if isinstance(node, Node):
            self.node = node
        else:
            self.node = None
        
    def getUUID(self):
        return self.uuidp
    
    def getID(self):
        return self.idp
    
    def getName(self):
        return self.namep
    
    def getState(self):
        if hasattr(self.node, 'state'):
            return self.node.state
        else:
            return None
        
    def getPublicIP(self):
        if hasattr(self.node, 'public_ips'):
            for ip in self.node.public_ips:
                return ip
        else:
            return ''
    
    def getPrivateIP(self):
        if hasattr(self.node, 'private_ips'):
            for ip in self.node.private_ips:
                return ip
        else:
            return ''
    
    def getSize(self):
        from NodeSizeImpl import NodeSizeImpl
        if hasattr(self.node, 'size'):
            return NodeSizeImpl(self.node.size)
        else:
            return NodeSizeImpl(None)
    
    def getImage(self):
        from NodeImageImpl import NodeImageImpl
        if hasattr(self.node, 'image'):
            return NodeImageImpl(self.node.image)
        else:
            return NodeImageImpl(None)
    
    def getExtra(self):
        return self.extrap
    
    def reboot(self):
        return self.node.reboot()
        
    def destroy(self):
        self.node.destroy()
    
    def toString(self):
        return self.reprp
    