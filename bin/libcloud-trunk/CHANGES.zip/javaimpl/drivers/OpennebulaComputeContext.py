from jlibcloud.driverSpecific.opennebula import OpenNebulaComputeContext
from jlibcloud.driverSpecific.opennebula import OpenNebulaNodeTemplateImpl

from javaimpl.ComputeContextImpl import ComputeContextImpl
from javaimpl.utils import wrap_listing
from javaimpl.utils import none_check

class OpenNebulaComputeContextImpl(ComputeContextImpl, OpenNebulaComputeContext):

	def __init__(self, builder):
		ComputeContextImpl.__init__(self, builder)

	def createNode(self, node_temp):
		kwargs = self._eval_template(node_temp)
		kwargs = self._parse_opennebula_template(node_temp, kwargs)
		self.conn.create_node(**kwargs)

	def _parse_opennebula_template(self, node_temp, kwargs):
		if node_temp.getNetworks():
			kwargs['networks'] =  node_temp.getNetworks()
		return kwargs

	def exListNetworks(self, location=None):
		"""
        List virtual networks on a provider.

        :type  location: :class:`NodeLocation`
        :param location: Location from which to request a list of virtual
                         networks. (optional)

        :return: List of virtual networks available to be connected to a
                 compute node.
        :rtype:  ``list`` of :class:`OpenNebulaNetwork`
        """
		if location:
			return wrap_listing(self.conn.ex_list_networks(location.location),
							 OpenNebulaNetworkImpl)
		else:
			return wrap_listing(self.conn.ex_list_networks(),
							 OpenNebulaNetworkImpl)

	def exNodeAction(self, node, action):
		"""
        Build action representation and instruct node to commit action.

        Build action representation from the compute node ID, and the
        action which should be carried out on that compute node. Then
        instruct the node to carry out that action.

        :param node: Compute node instance.
        :type  node: :class:`Node`

        :param action: Action to be carried out on the compute node.
        :type  action: ``str``

        :return: False if an HTTP Bad Request is received, else, True is
                 returned.
        :rtype:  ``bool``
        """
		return self.conn.ex_node_action(node.node, action)

	def getTemplateBuilder(self):
		return OpenNebulaNodeTemplateImpl.newBuilder()

from jlibcloud.driverSpecific.opennebula import OpenNebula_2_0_ComputeContext
from jlibcloud.driverSpecific.opennebula import OpenNebula_2_0_NodeTemplateImpl

class OpenNebula_2_0_ComputeContextImpl(OpenNebulaComputeContextImpl, 
									OpenNebula_2_0_ComputeContext):

	def __init__(self, builder):
		OpenNebulaComputeContextImpl.__init__(self, builder)

	def createNode(self, node_temp):
		kwargs = self._eval_template(node_temp)
		kwargs = self._parse_opennebula_2_0__template(node_temp, kwargs)
		self.conn.create_node(**kwargs)

	def _parse_opennebula_2_0__template(self, node_temp, kwargs):
		if node_temp.getNetworks():
			kwargs['networks'] =  node_temp.getNetworks()
		if node_temp.getContext():
			kwargs['context'] =  node_temp.getContext()
		return kwargs

	def getTemplateBuilder(self):
		return OpenNebula_2_0_NodeTemplateImpl.newBuilder()
	
from jlibcloud.driverSpecific.opennebula import OpenNebula_3_0_ComputeContext

class OpenNebula_3_0_ComputeContextImpl(OpenNebula_2_0_ComputeContextImpl, 
									OpenNebula_3_0_ComputeContext):

	def __init__(self, builder):
		OpenNebula_2_0_ComputeContextImpl.__init__(self, builder)

	def exNodeSetSaveName(self, node, name):
		"""
        Build action representation and instruct node to commit action.

        Build action representation from the compute node ID, the disk image
        which will be saved, and the name under which the image will be saved
        upon shutting down the compute node.

        :param node: Compute node instance.
        :type  node: :class:`Node`

        :param name: Name under which the image should be saved after shutting
                     down the compute node.
        :type  name: ``str``

        :return: False if an HTTP Bad Request is received, else, True is
                 returned.
        :rtype:  ``bool``
        """
		return self.conn.ex_node_set_save_name(node.node, name)

from jlibcloud.driverSpecific.opennebula import OpenNebulaNodeSize as JOpenNebulaNodeSize
from javaimpl.base.NodeSizeImpl import NodeSizeImpl

class OpenNebulaNodeSizeImpl(JOpenNebulaNodeSize):

	def __init__(self, obj):
		NodeSizeImpl.__init__(self, obj)
		if hasattr(obj, 'cpu'):
			self.cpup = none_check(obj.cpu, '')
		else:
			self.cpup = ''
		if hasattr(obj, 'vcpu'):
			self.vcpup = none_check(obj.vcpu, '')
		else:
			self.vcpup = ''
		if hasattr(obj, '__repr__()'):
			self.reprp = obj.__repr__()
		else:
			self.reprp = ''
       
	def getCpu(self):
		return self.cpup

	def getVcpu(self):
		return self.vcpup

	def toString(self):
		return self.reprp

		
from jlibcloud.driverSpecific.opennebula import OpenNebulaNetwork as JOpenNebulaNetwork

class OpenNebulaNetworkImpl(JOpenNebulaNetwork):

	def __init__(self, obj):
		self.conn = obj
		if hasattr(obj, 'id'):
			self.idp = none_check(obj.id, '')
		else:
			self.idp = ''
		if hasattr(obj, 'address'):
			self.addressp = none_check(obj.address, '')
		else:
			self.addressp = ''
		if hasattr(obj, 'name'):
			self.namep = none_check(obj.name, '')
		else:
			self.namep = ''
		if hasattr(obj, 'size'):
			self.sizep = none_check(obj.size, '')
		else:
			self.sizep = ''
		if hasattr(obj, 'extra'):
			self.extrap = obj.extra
		else:
			self.extrap = ''
		if hasattr(obj, '__repr__()'):
			self.reprp = obj.__repr__()
		else:
			self.reprp = ''

	def getUuid(self):
		return self.conn.get_uuid()

	def getId(self):
		return self.idp
	
	def getAddress(self):
		return self.addressp

	def getName(self):
		return self.namep

	def getSize(self):
		return self.sizep

	def getExtra(self):
		return self.extrap
	
	def toString(self):
		return self.reprp

	