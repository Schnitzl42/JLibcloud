from jlibcloud.driverSpecific.cloudframes import CloudFramesComputeContext
from jlibcloud.driverSpecific.cloudframes import CloudFramesNodeTemplateImpl

from javaimpl.ComputeContextImpl import ComputeContextImpl
from javaimpl.utils import wrap_listing
from javaimpl.utils import none_check

class CloudFramesComputeContextImpl(ComputeContextImpl, CloudFramesComputeContext):

	def __init__(self, builder):
		ComputeContextImpl.__init__(self, builder)

	def createNode(self, node_temp):
		kwargs = self._eval_template(node_temp)
		kwargs = self._parse_cloudframes_template(node_temp, kwargs)
		self.conn.create_node(**kwargs)

	def _parse_cloudframes_template(self, node_temp, kwargs):
		if node_temp.getExtra():
			kwargs['extra'] =  node_temp.getExtra()
		if node_temp.getDefaultGateway():
			kwargs['default_gateway'] =  node_temp.getDefaultGateway()
		return kwargs
	
	#--------------------------------------------#
    # methods for listing information            #
    #--------------------------------------------#
	def listNodes(self):
		return wrap_listing(self.conn.list_nodes(), CloudFramesNodeImpl)

	def listSizes(self):
		return wrap_listing(self._list_sizes(), CloudFramesNodeSizeImpl)
    
    #--------------------------------------------#
    # provider specific methods		             #
    #--------------------------------------------#
	def exSnapshotNode(self, node, label='', description=''):
		return self.conn.ex_snapshot_node(node, label, description)

	def exRollbackNode(self, node, snapshot):
		return self.conn.ex_rollback_node(node, snapshot)

	def exListSnapshots(self, node):
		return self.conn.ex_list_snapshots(node)

	def exDestroySnapshot(self, node, snapshot):
		return self.conn.ex_destroy_snapshot(node, snapshot)

	def getTemplateBuilder(self):
		return CloudFramesNodeTemplateImpl.newBuilder()


from jlibcloud.driverSpecific.cloudframes import CloudFramesNodeSize as JCloudFramesNodeSize

class CloudFramesNodeSizeImpl(JCloudFramesNodeSize):

	def __init__(self, obj):
		self.conn = obj
		if hasattr(obj, 'vcpus'):
			self.vcpusp = none_check(obj.vcpus, -1)
		else:
			self.vcpusp = -1

	def getVcpus(self):
		return self.vcpusp

from jlibcloud.driverSpecific.cloudframes import CloudFramesNode as JCloudFramesNode

class CloudFramesNodeImpl(JCloudFramesNode):

	def listSnapshots(self):
		return self.conn.list_snapshots()

	def snapshot(self, label='', description=''):
		return self.conn.snapshot(label, description)

	def rollback(self, snapshot):
		return self.conn.rollback(snapshot)

from jlibcloud.driverSpecific.cloudframes import CloudFramesSnapshot as JCloudFramesSnapshot

class CloudFramesSnapshotImpl(JCloudFramesSnapshot):

	def __init__(self, obj):
		self.conn = obj
		if hasattr(obj, 'timestamp'):
			self.timestampp = none_check(obj.timestamp, '')
		else:
			self.timestampp = ''
		if hasattr(obj, 'id'):
			self.idp = none_check(obj.id, '')
		else:
			self.idp = ''
		if hasattr(obj, 'description'):
			self.descriptionp = none_check(obj.description, '')
		else:
			self.descriptionp = ''
		if hasattr(obj, 'label'):
			self.labelp = none_check(obj.label, '')
		else:
			self.labelp = ''

	def getTimestamp(self):
		return self.timestampp

	def getId(self):
		return self.idp

	def getDescription(self):
		return self.descriptionp

	def getLabel(self):
		return self.labelp

	def destroy(self):
		return self.conn.destroy()
