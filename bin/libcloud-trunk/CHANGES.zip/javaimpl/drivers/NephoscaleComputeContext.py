from jlibcloud.driverSpecific.nephoscale import NephoscaleComputeContext
from jlibcloud.driverSpecific.nephoscale import NephoscaleNodeTemplateImpl

from javaimpl.ComputeContextImpl import ComputeContextImpl
from javaimpl.utils import wrap_listing
from javaimpl.utils import none_check

class NephoscaleComputeContextImpl(ComputeContextImpl, NephoscaleComputeContext):

	def __init__(self, builder):
		ComputeContextImpl.__init__(self, builder)

	def exStartNode(self, node):
		return self.conn.ex_start_node(node.node)

	def exStopNode(self, node):
		return self.conn.ex_stop_node(node.node)

	def exListKeypairs(self, ssh=False, password=False, key_group=None):
		return wrap_listing(self.conn.ex_list_keypairs(ssh, password, key_group), NodeKeyImpl)

	def exCreateKeypair(self, name, public_key=None, password=None,
                          key_group=None):
		'''
           The group for the key (key_group) is 1 for Server and 4 for Console
           Returns the id of the created key
		'''
		return self.conn.ex_create_keypair(self, name, public_key, password, key_group)

	def exDeleteKeypair(self, key_id, ssh=False):
		'''Delete an ssh key or password given it's id
		'''
		return self.conn.ex_delete_keypair(key_id, ssh)

	def createNode(self, node_temp):
		kwargs = self._eval_template(node_temp)
		kwargs = self._parse_nephoscale_template(node_temp, kwargs)
		self.conn.create_node(**kwargs)

	def _parse_nephoscale_template(self, node_temp, kwargs):
		if node_temp.getServerKey():
			kwargs['server_key'] = node_temp.getServerKey()
		if node_temp.getConsoleKey():
			kwargs['console_key'] = node_temp.getConsoleKey()
		if node_temp.getZone():
			kwargs['zone'] = node_temp.getZone()
		if node_temp.getHostname():
			kwargs['hostname'] = node_temp.getHostname()
		if node_temp.getExWait():
			kwargs['ex_wait'] = node_temp.getExWait()
		return kwargs

	def getTemplateBuilder(self):
		return NephoscaleNodeTemplateImpl.newBuilder()

from jlibcloud.driverSpecific.nephoscale import NodeKey as JNodeKey

class NodeKeyImpl(JNodeKey):

	def __init__(self, obj):
		self.conn = obj
		if hasattr(obj, 'id'):
			self.idp = none_check(obj.id, '')
		else:
			self.idp = ''
		if hasattr(obj, 'name'):
			self.namep = none_check(obj.name, '')
		else:
			self.namep = ''
		if hasattr(obj, 'key_group'):
			self.key_groupp = none_check(obj.key_group, '')
		else:
			self.key_groupp = ''
		if hasattr(obj, 'public_key'):
			self.public_keyp = none_check(obj.public_key, '')
		else:
			self.public_keyp = ''
		if hasattr(obj, 'password'):
			self.passwordp = none_check(obj.password, '')
		else:
			self.passwordp = ''
		if hasattr(obj, '__repr__()'):
			self.reprp = obj.__repr__()
		else:
			self.reprp = ''

	def getId(self):
		return self.idp

	def getName(self):
		return self.namep

	def getKeyGroup(self):
		return self.key_groupp

	def getPublicKey(self):
		return self.public_keyp

	def getPassword(self):
		return self.passwordp

	def toString(self):
		return self.reprp
	