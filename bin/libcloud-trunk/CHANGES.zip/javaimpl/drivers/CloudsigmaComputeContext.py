from jlibcloud.driverSpecific.cloudsigma import CloudSigmaCompute_1_0_Context
from jlibcloud.driverSpecific.cloudsigma import CloudSigmaCompute_2_0_Context
from jlibcloud.driverSpecific.cloudsigma import CloudSigmaNodeTemplateImpl

from javaimpl.ComputeContextImpl import ComputeContextImpl
from javaimpl.utils import wrap_listing
from javaimpl.utils import none_check

from javaimpl.base.NodeImpl import NodeImpl

class CloudSigma_1_0_ComputeContextImpl(ComputeContextImpl, CloudSigma_1_0_ComputeContext):

	def __init__(self, builder):
		ComputeContextImpl.__init__(self, builder)

	def createNode(self, node_temp):
		kwargs = self._eval_template(node_temp)
		kwargs = self._parse_cloudsigma_1_0__template(node_temp, kwargs)
		self.conn.create_node(**kwargs)

	def _parse_cloudsigma_1_0__template(self, node_temp, kwargs):
		if node_temp.getSmp():
			kwargs['smp'] =  node_temp.getSmp()
		if node_temp.getVncPassword():
			kwargs['vnc_password'] =  node_temp.getVncPassword()
		if node_temp.getDriveType():
			kwargs['drive_type'] =  node_temp.getDriveType()
		if node_temp.getNicModel():
			kwargs['nic_model'] =  node_temp.getNicModel()
		return kwargs

	def exDestroyNodeAndDrives(self, node):
		'''
        Destroy a node and all the drives associated with it.

        :param      node: Node which should be used
        :type       node: :class:`libcloud.compute.base.Node`

        :rtype: ``bool``
		'''
		return self.conn.ex_destroy_node_and_drives(node.node)

	def exStaticIpList(self):
		'''
        Return a list of available static IP addresses.

        :rtype: ``list`` of ``str``
		'''
		return self.conn.ex_static_ip_list()

	def exDrivesList(self):
		'''
        Return a list of all the available drives.

        :rtype: ``list`` of ``dict``
		'''
		return self.conn.ex_drives_list()

	def exStaticIpCreate(self):
		'''
        Create a new static IP address.p

        :rtype: ``list`` of ``dict``
		'''
		return self.conn.ex_static_ip_create()

	def exStaticIpDestroy(self, ip_address):
		'''
        Destroy a static IP address.

        :param      ip_address: IP address which should be used
        :type       ip_address: ``str``

        :rtype: ``bool``
		'''
		return self.conn.ex_static_ip_destroy(ip_address)

	def exDriveDestroy(self, drive_uuid):
		'''
        Destroy a drive with a specified uuid.
        If the drive is currently mounted an exception is thrown.

        :param      drive_uuid: Drive uuid which should be used
        :type       drive_uuid: ``str``

        :rtype: ``bool``
		'''
		return self.conn.ex_drive_destroy(drive_uuid)

	def exSetNodeConfiguration(self, node, kwargs):
		'''
        Update a node configuration.
        Changing most of the parameters requires node to be stopped.

        :param      node: Node which should be used
        :type       node: :class:`libcloud.compute.base.Node`

        :param      kwargs: keyword arguments
        :type       kwargs: ``dict``

        :rtype: ``bool``
		'''
		return self.conn.ex_set_node_configuration(node.node, **kwargs)

	def exStartNode(self, node):
		'''
        Start a node.

        :param      node: Node which should be used
        :type       node: :class:`libcloud.compute.base.Node`

        :rtype: ``bool``
		'''
		return self.conn.ex_start_node(node.node)

	def exStopNode(self, node):
		'''
        Stop (shutdown) a node.

        :param      node: Node which should be used
        :type       node: :class:`libcloud.compute.base.Node`

        :rtype: ``bool``
		'''
		return self.conn.ex_stop_node(node.node)

	def exShutdownNode(self, node):
		'''
        Stop (shutdown) a node.

        @inherits: :class:`CloudSigmaBaseNodeDriver.ex_stop_node`
		'''
		return self.conn.ex_shutdown_node(node.node)

	def exDestroyDrive(self, drive_uuid):
		'''
        Destroy a drive.

        :param      drive_uuid: Drive uuid which should be used
        :type       drive_uuid: ``str``

        :rtype: ``bool``
		'''
		return self.conn.ex_destroy_drive(drive_uuid)

	def getTemplateBuilder(self):
		return CloudSigma_1_0_NodeTemplateImpl.newBuilder()

class CloudSigma_2_0_ComputeContextImpl(ComputeContextImpl, CloudSigma_2_0_ComputeContext):

	def __init__(self, builder):
		ComputeContextImpl.__init__(self, builder)

	def createNode(self, node_temp):
		kwargs = self._eval_template(node_temp)
		kwargs = self._parse_cloudsigma_2_0__template(node_temp, kwargs)
		self.conn.create_node(**kwargs)

	def _parse_cloudsigma_2_0__template(self, node_temp, kwargs):
		if node_temp.getExVncPassword():
			kwargs['ex_vnc_password'] =  node_temp.getExVncPassword()
		if node_temp.getExMetadata():
			kwargs['ex_metadata'] =  node_temp.getExMetadata()
		if node_temp.getExVlan():
			kwargs['ex_vlan'] =  node_temp.getExVlan()
		if node_temp.getExAvoid():
			kwargs['ex_avoid'] =  node_temp.getExAvoid()
		return kwargs

	def exEditNode(self, node, params):
		'''
        Edit a node.

        :param node: Node to edit.
        :type node: :class:`libcloud.compute.base.Node`

        :param params: Node parameters to update.
        :type params: ``dict``

        :return Edited node.
        :rtype: :class:`libcloud.compute.base.Node`
		'''
		return NodeImpl(self.conn.ex_edit_node(node.node, params))

	def exStartNode(self, node, ex_avoid=None):
		'''
        Start a node.

        :param node: Node to start.
        :type node: :class:`libcloud.compute.base.Node`

        :param ex_avoid: A list of other server uuids to avoid when
                         starting this node. If provided, node will
                         attempt to be started on a different
                         physical infrastructure from other servers
                         specified using this argument. (optional)
        :type ex_avoid: ``list``
		'''
		if ex_avoid:
			return self.conn.ex_start_node(node.node, ex_avoid)
		else:
			return self.conn.ex_start_node(node.node)

	def exStopNode(self, node):
		'''
        Stop a node.
		'''
		return self.conn.ex_stop_node(node.node)

	def exCloneNode(self, node, name=None, random_vnc_password=None):
		'''
        Clone the provided node.

        :param name: Optional name for the cloned node.
        :type name: ``str``
        :param random_vnc_password: If True, a new random VNC password will be
                                    generated for the cloned node. Otherwise
                                    password from the cloned node will be
                                    reused.
        :type random_vnc_password: ``bool``

        :return: Cloned node.
        :rtype: :class:`libcloud.compute.base.Node`
		'''
		if name and random_vnc_password:
			return NodeImpl(self.conn.ex_clone_node(node.node, name, random_vnc_password))
		elif name and not random_vnc_password:
			return NodeImpl(self.conn.ex_clone_node(node.node, name))
		else:
			return NodeImpl(self.conn.ex_clone_node(node.node))

	def exOpenVncTunnel(self, node):
		'''
        Open a VNC tunnel to the provided node and return the VNC url.

        :param node: Node to open the VNC tunnel to.
        :type node: :class:`libcloud.compute.base.Node`

        :return: URL of the opened VNC tunnel.
        :rtype: ``str``
		'''
		return self.conn.ex_open_vnc_tunnel(node.node)

	def exCloseVncTunnel(self, node):
		'''
        Close a VNC server to the provided node.

        :param node: Node to close the VNC tunnel to.
        :type node: :class:`libcloud.compute.base.Node`

        :return: ``True`` on success, ``False`` otherwise.
        :rtype: ``bool``
		'''
		return self.conn.ex_close_vnc_tunnel(node.node)

	def exListLibraryDrives(self):
		'''
        Return a list of all the available library drives (pre-installed and
        installation CDs).

        :rtype: ``list`` of :class:`.CloudSigmaDrive` objects
		'''
		return wrap_listing(self.conn.ex_list_library_drives(), CloudSigmaDriveImpl)

	def exListUserDrives(self):
		'''
        Return a list of all the available user's drives.

        :rtype: ``list`` of :class:`.CloudSigmaDrive` objects
		'''
		return wrap_listing(self.conn.ex_list_user_drives(), CloudSigmaDriveImpl)

	def exCreateDrive(self, name, size, media, ex_avoid):
		'''
        Create a new drive.

        :param name: Drive name.
        :type name: ``str``

        :param size: Drive size in bytes.
        :type size: ``int``

        :param media: Drive media type (cdrom, disk).
        :type media: ``str``

        :param ex_avoid: A list of other drive uuids to avoid when
                         creating this drive. If provided, drive will
                         attempt to be created on a different
                         physical infrastructure from other drives
                         specified using this argument. (optional)
        :type ex_avoid: ``list``

        :return: Created drive object.
        :rtype: :class:`.CloudSigmaDrive`
		'''
		if ex_avoid:
			return CloudSigmaDriveImpl(self.conn.ex_create_drive(name, size, media, ex_avoid))
		else:
			return CloudSigmaDriveImpl(self.conn.ex_create_drive(name, size, media))

	def exCloneDrive(self, drive, name=None, ex_avoid=None):
		'''
        Clone a library or a standard drive.

        :param drive: Drive to clone.
        :type drive: :class:`libcloud.compute.base.NodeImage` or
                     :class:`.CloudSigmaDrive`

        :param name: Optional name for the cloned drive.
        :type name: ``str``

        :param ex_avoid: A list of other drive uuids to avoid when
                         creating this drive. If provided, drive will
                         attempt to be created on a different
                         physical infrastructure from other drives
                         specified using this argument. (optional)
        :type ex_avoid: ``list``

        :return: New cloned drive.
        :rtype: :class:`.CloudSigmaDrive`
		'''
		if  name and ex_avoid:
			return CloudSigmaDriveImpl(self.conn.ex_clone_drive(drive.image, name, ex_avoid))
		elif name and not ex_avoid:
			return CloudSigmaDriveImpl(self.conn.ex_clone_drive(drive.image, name))
		else:
			return CloudSigmaDriveImpl(self.conn.ex_clone_drive(drive.image.drive))

	def exResizeDrive(self,drive, size):
		'''
        Resize a drive.

        :param drive: Drive to resize.

        :param size: New drive size in bytes.
        :type size: ``int``

        :return: Drive object which is being resized.
        :rtype: :class:`.CloudSigmaDrive`
		'''
		return CloudSigmaDriveImpl(self.conn.ex_resize_drive(drive.node, size))

	def exAttachDrive(self, node):
		'''
        Attach a drive to the provided node.
		'''
		return self.conn.ex_attach_drive(node.node)

	def exGetDrive(self, drive_id):
		'''
        Retrieve information about a single drive.

        :param drive_id: ID of the drive to retrieve.
        :type drive_id: ``str``

        :return: Drive object.
        :rtype: :class:`.CloudSigmaDrive`
		'''
		return CloudSigmaDriveImpl(sself.conn.ex_get_drive(drive_id))

	def exListFirewallPolicies(self):
		'''
        List firewall policies.

        :rtype: ``list`` of :class:`.CloudSigmaFirewallPolicy`
		'''
		return wrap_listing(self.conn.ex_list_firewall_policies(), CloudSigmaFirewallPolicyImpl)

	def exCreateFirewallPolicy(self, name, rules):
		'''
        Create a firewall policy.

        :param name: Policy name.
        :type name: ``str``

        :param rules: List of firewall policy rules to associate with this
                      policy. (optional)
        :type rules: ``list`` of ``dict``

        :return: Created firewall policy object.
        :rtype: :class:`.CloudSigmaFirewallPolicy`
		'''
		if rules:
			return CloudSigmaFirewallPolicyImpl(self.conn.ex_create_firewall_policy(name, rules))
		else:
			return CloudSigmaFirewallPolicyImpl(self.conn.ex_create_firewall_policy(name))
		
	def exAttachFirewallPolicy(self, policy, node, nic_mac):
		'''
        Attach firewall policy to a public NIC interface on the server.

        :param policy: Firewall policy to attach.
        :type policy: :class:`.CloudSigmaFirewallPolicy`

        :param node: Node to attach policy to.
        :type node: :class:`libcloud.compute.base.Node`

        :param nic_mac: Optional MAC address of the NIC to add the policy to.
                        If not specified, first public interface is used
                        instead.
        :type nic_mac: ``str``

        :return: Node object to which the policy was attached to.
        :rtype: :class:`libcloud.compute.base.Node`
		'''
		if nic_mac:
			return NodeImpl(self.conn.ex_attach_firewall_policy(policy, node, nic_mac))
		else:
			return NodeImpl(self.conn.ex_attach_firewall_policy(policy, node))

	def exDeleteFirewallPolicy(self, policy):
		'''
        Delete a firewall policy.

        :param policy: Policy to delete to.
        :type policy: :class:`.CloudSigmaFirewallPolicy`

        :return: ``True`` on success, ``False`` otherwise.
        :rtype: ``bool``
		'''
		return self.conn.ex_delete_firewall_policy(policy.policy)

	def exListServersAvailabilityGroups(self):
		'''
        Return which running servers share the same physical compute host.

        :return: A list of server UUIDs which share the same physical compute
                 host. Servers which share the same host will be stored under
                 the same list index.
        :rtype: ``list`` of ``list``
		'''
		return self.conn.ex_list_servers_availability_groups()

	def exListDrivesAvailabilityGroups(self):
		'''
        Return which drives share the same physical storage host.

        :return: A list of drive UUIDs which share the same physical storage
                 host. Drives which share the same host will be stored under
                 the same list index.
        :rtype: ``list`` of ``list``
		'''
		return self.conn.ex_list_drives_availability_groups()

	def exListTags(self):
		'''
        List all the available tags.

        :rtype: ``list`` of :class:`.CloudSigmaTag` objects
		'''
		return wrap_listing(self.conn.ex_list_tags(), CloudSigmaTagImpl)

	def exGetTag(self, id):
		'''
        Retrieve a single tag.

        :param id: ID of the tag to retrieve.
        :type id: ``str``

        :rtype: ``list`` of :class:`.CloudSigmaTag` objects
		'''
		return wrap_listing(self.conn.ex_get_tag(tag_id), CloudSigmaTagImpl)

	def exCreateTag(self, name, resource_uuids=None):
		'''
        Create a tag.

        :param name: Tag name.
        :type name: ``str``

        :param resource_uuids: Optional list of resource UUIDs to assign this
                               tag go.
        :type resource_uuids: ``list`` of ``str``

        :return: Created tag object.
        :rtype: :class:`.CloudSigmaTag`
		'''
		if resource_uuids:
			return CloudSigmaTagImpl(self.conn.ex_create_tag(name, resource_uuids))
		else:
			return CloudSigmaTagImpl(self.conn.ex_create_tag(name))

	def exTagResource(self, resource, tag):
		'''
        Associate tag with the provided resource.

        :param resource: Resource to associate a tag with.
        :type resource: :class:`libcloud.compute.base.Node` or
                        :class:`.CloudSigmaDrive`

        :param tag: Tag to associate with the resources.
        :type tag: :class:`.CloudSigmaTag`

        :return: Updated tag object.
        :rtype: :class:`.CloudSigmaTag`
		'''
		return CloudSigmaTagImpl(self.conn.ex_tag_resource(resource.node, tag.tag))

	def exTagResources(self, resource, tag):
		'''
        Associate tag with the provided resources.

        :param resource: Resources to associate a tag with.
        :type resource: ``list`` of :class:`libcloud.compute.base.Node` or
                        :class:`.CloudSigmaDrive`

        :param tag: Tag to associate with the resources.
        :type tag: :class:`.CloudSigmaTag`

        :return: Updated tag object.
        :rtype: :class:`.CloudSigmaTag`
		'''
		return CloudSigmaTagImpl(self.conn.ex_tag_resources(resources, tag))

	def exDeleteTag(self, tag):
		'''
        Delete a tag.

        :param tag: Tag to delete.
        :type tag: :class:`.CloudSigmaTag`

        :return: ``True`` on success, ``False`` otherwise.
        :rtype: ``bool``
		'''
		return self.conn.ex_delete_tag(tag.tag)

	def exGetBalance(self):
		'''
        Retrueve account balance information.

        :return: Dictionary with two items ("balance" and "currency").
        :rtype: ``dict``
		'''
		return self.conn.ex_get_balance()

	def exGetPricing(self):
		'''
        Retrive pricing information that are applicable to the cloud.

        :return: Dictionary with pricing information.
        :rtype: ``dict``
		'''
		return self.conn.ex_get_pricing()

	def exGetUsage(self):
		'''
        Retrieve account current usage information.

        :return: Dictionary with two items ("balance" and "usage").
        :rtype: ``dict``
		'''
		return self.conn.ex_get_usage()

	def exListSubscriptions(self, status='all', resources=None):
		'''
        List subscriptions for this account.

        :param status: Only return subscriptions with the provided status
                       (optional).
        :type status: ``str``
        :param resources: Only return subscriptions for the provided resources
                          (optional).
        :type resources: ``list``

        :rtype: ``list``
		'''
		if status and ressources:
			return wrap_listing(self.conn.ex_list_subscriptions(status='all', resources),
							CloudSigmaSubscriptionImpl)
		else:
			return wrap_listing(self.conn.ex_list_subscriptions(status), 
							CloudSigmaSubscriptionImpl)

	def exToggleSubscriptionAutoRenew(self, subscription):
		'''
        Toggle subscription auto renew status.

        :param subscription: Subscription to toggle the auto renew flag for.
        :type subscription: :class:`.CloudSigmaSubscription`

        :return: ``True`` on success, ``False`` otherwise.
        :rtype: ``bool``
		'''
		return self.conn.ex_toggle_subscription_auto_renew(subscription.obj)

	def exCreateSubscription(self, amount, period, resource, auto_renew=False):
		'''
        Create a new subscription.

        :param amount: Subscription amount. For example, in dssd case this
                       would be disk size in gigabytes.
        :type amount: ``int``

        :param period: Subscription period. For example: 30 days, 1 week, 1
                                            month, ...
        :type period: ``str``

        :param resource: Resource the purchase the subscription for.
        :type resource: ``str``

        :param auto_renew: True to automatically renew the subscription.
        :type auto_renew: ``bool``
		'''
		return CloudSigmaSubscriptionImpl(self.conn.ex_create_subscription(amount,
																		 period, resource, auto_renew))

	def exListCapabilities(self):
		'''
        Retrieve all the basic and sensible limits of the API.

        :rtype: ``dict``
		'''
		return self.conn.ex_list_capabilities()

	def getTemplateBuilder(self):
		return CloudSigma_2_0_NodeTemplateImpl.newBuilder()

from jlibcloud.driverSpecific.cloudsigma import CloudSigmaNodeSize as JCloudSigmaNodeSize
from javaimpl.base.NodeSizeImpl import NodeSizeImpl

class CloudSigmaNodeSizeImpl(JCloudSigmaNodeSize, NodeSizeImpl):

	def __init__(self, obj):
		self.size = obj
		NodeSizeImpl.__init__(self, obj)
		if hasattr(obj, 'id'):
			self.idp = none_check(obj.id, '')
		else:
			self.idp = ''
		if hasattr(obj, 'price'):
			self.pricep = none_check(obj.price, '')
		else:
			self.pricep = ''
		if hasattr(obj, 'ram'):
			self.ramp = none_check(obj.ram, '')
		else:
			self.ramp = ''
		if hasattr(obj, 'disk'):
			self.diskp = none_check(obj.disk, '')
		else:
			self.diskp = ''
		if hasattr(obj, 'name'):
			self.namep = none_check(obj.name, '')
		else:
			self.namep = ''
		if hasattr(obj, 'cpu'):
			self.cpup = none_check(obj.cpu, '')
		else:
			self.cpup = ''
		if hasattr(obj, 'bandwidth'):
			self.bandwidthp = none_check(obj.bandwidth, -1)
		else:
			self.bandwidthp = -1
		if hasattr(obj, '__repr__()'):
			self.reprp = obj.__repr__()
		else:
			self.reprp = ''

	def getId(self):
		return self.idp

	def getPrice(self):
		return self.pricep

	def getRam(self):
		return self.ramp

	def getDisk(self):
		return self.diskp

	def getName(self):
		return self.namep

	def getCpu(self):
		return self.cpup

	def getBandwidth(self):
		return self.bandwidthp

	def toString(self):
		return self.reprp

from jlibcloud.driverSpecific.cloudsigma import CloudSigmaError as JCloudSigmaError

class CloudSigmaErrorImpl(JCloudSigmaError):

	def __init__(self, obj):
		self.obj = obj
		if hasattr(obj, 'error_type'):
			self.error_typep = none_check(obj.error_type, '')
		else:
			self.error_typep = ''
		if hasattr(obj, 'error_point'):
			self.error_pointp = none_check(obj.error_point, '')
		else:
			self.error_pointp = ''
		if hasattr(obj, 'error_msg'):
			self.error_msgp = none_check(obj.error_msg, '')
		else:
			self.error_msgp = ''
		if hasattr(obj, '__repr__()'):
			self.reprp = obj.__repr__()
		else:
			self.reprp = ''

	def getError_type(self):
		return self.error_typep

	def getError_point(self):
		return self.error_pointp

	def getError_msg(self):
		return self.error_msgp

	def toString(self):
		return self.reprp

from jlibcloud.driverSpecific.cloudsigma import CloudSigmaSubscription as JCloudSigmaSubscription

class CloudSigmaSubscriptionImpl(JCloudSigmaSubscription):

	def __init__(self, obj):
		self.obj = obj
		if hasattr(obj, 'amount'):
			self.amountp = none_check(obj.amount, '')
		else:
			self.amountp = ''
		if hasattr(obj, 'id'):
			self.idp = none_check(obj.id, '')
		else:
			self.idp = ''
		if hasattr(obj, 'price'):
			self.pricep = none_check(obj.price, '')
		else:
			self.pricep = ''
		if hasattr(obj, 'end_time'):
			self.end_timep = none_check(obj.end_time, '')
		else:
			self.end_timep = ''
		if hasattr(obj, 'status'):
			self.statusp = none_check(obj.status, '')
		else:
			self.statusp = ''
		if hasattr(obj, 'auto_renew'):
			self.auto_renewp = none_check(obj.auto_renew, '')
		else:
			self.auto_renewp = ''
		if hasattr(obj, 'resource'):
			self.resourcep = none_check(obj.resource, '')
		else:
			self.resourcep = ''
		if hasattr(obj, 'start_time'):
			self.start_timep = none_check(obj.start_time, '')
		else:
			self.start_timep = ''
		if hasattr(obj, 'subscribed_object'):
			self.subscribed_objectp = none_check(obj.subscribed_object, '')
		else:
			self.subscribed_objectp = ''
		if hasattr(obj, 'period'):
			self.periodp = none_check(obj.period, '')
		else:
			self.periodp = ''
		if hasattr(obj, '__repr__()'):
			self.reprp = obj.__repr__()
		else:
			self.reprp = ''

	def getAmount(self):
		return self.amountp

	def getId(self):
		return self.idp

	def getPrice(self):
		return self.pricep

	def getEnd_time(self):
		return self.end_timep

	def getStatus(self):
		return self.statusp

	def getAuto_renew(self):
		return self.auto_renewp

	def getResource(self):
		return self.resourcep

	def getStart_time(self):
		return self.start_timep

	def getSubscribed_object(self):
		return self.subscribed_objectp

	def getPeriod(self):
		return self.periodp

	def toString(self):
		return self.reprp

from jlibcloud.driverSpecific.cloudsigma import CloudSigmaTag as JCloudSigmaTag

class CloudSigmaTagImpl(JCloudSigmaTag):

	def __init__(self, obj):
		self.tag = obj
		if hasattr(obj, 'id'):
			self.idp = none_check(obj.id, '')
		else:
			self.idp = ''
		if hasattr(obj, 'name'):
			self.namep = none_check(obj.name, '')
		else:
			self.namep = ''
		if hasattr(obj, '__repr__()'):
			self.reprp = obj.__repr__()
		else:
			self.reprp = ''

	def getId(self):
		return self.idp

	def getName(self):
		return self.namep

	def toString(self):
		return self.reprp

from jlibcloud.driverSpecific.cloudsigma import CloudSigmaDrive as JCloudSigmaDrive

class CloudSigmaDriveImpl(JCloudSigmaDrive):

	def __init__(self, obj):
		self.node = obj
		if hasattr(obj, 'status'):
			self.statusp = none_check(obj.status, '')
		else:
			self.statusp = ''
		if hasattr(obj, 'media'):
			self.mediap = none_check(obj.media, '')
		else:
			self.mediap = ''
		if hasattr(obj, 'size'):
			self.sizep = none_check(obj.size, '')
		else:
			self.sizep = ''
		if hasattr(obj, '__repr__()'):
			self.reprp = obj.__repr__()
		else:
			self.reprp = ''

	def getStatus(self):
		return self.statusp

	def getMedia(self):
		return self.mediap

	def getSize(self):
		return self.sizep

	def toString(self):
		return self.reprp

from jlibcloud.driverSpecific.cloudsigma import CloudSigmaFirewallPolicy as JCloudSigmaFirewallPolicy

class CloudSigmaFirewallPolicyImpl(JCloudSigmaFirewallPolicy):

	def __init__(self, obj):
		self.policy = obj
		if hasattr(obj, 'id'):
			self.idp = none_check(obj.id, '')
		else:
			self.idp = ''
		if hasattr(obj, 'name'):
			self.namep = none_check(obj.name, '')
		else:
			self.namep = ''
		if hasattr(obj, '__repr__()'):
			self.reprp = obj.__repr__()
		else:
			self.reprp = ''

	def getId(self):
		return self.idp

	def getName(self):
		return self.namep

	def toString(self):
		return self.reprp

from jlibcloud.driverSpecific.cloudsigma import CloudSigmaFirewallPolicyRule as JCloudSigmaFirewallPolicyRule

class CloudSigmaFirewallPolicyRuleImpl(JCloudSigmaFirewallPolicyRule):

	def __init__(self, obj):
		self.obj = obj
		if hasattr(obj, 'dst_port'):
			self.dst_portp = none_check(obj.dst_port, '')
		else:
			self.dst_portp = ''
		if hasattr(obj, 'dst_ip'):
			self.dst_ipp = none_check(obj.dst_ip, '')
		else:
			self.dst_ipp = ''
		if hasattr(obj, 'direction'):
			self.directionp = none_check(obj.direction, '')
		else:
			self.directionp = ''
		if hasattr(obj, 'action'):
			self.actionp = none_check(obj.action, '')
		else:
			self.actionp = ''
		if hasattr(obj, 'src_ip'):
			self.src_ipp = none_check(obj.src_ip, '')
		else:
			self.src_ipp = ''
		if hasattr(obj, 'ip_proto'):
			self.ip_protop = none_check(obj.ip_proto, '')
		else:
			self.ip_protop = ''
		if hasattr(obj, 'comment'):
			self.commentp = none_check(obj.comment, '')
		else:
			self.commentp = ''
		if hasattr(obj, 'src_port'):
			self.src_portp = none_check(obj.src_port, '')
		else:
			self.src_portp = ''
		if hasattr(obj, '__repr__()'):
			self.reprp = obj.__repr__()
		else:
			self.reprp = ''

	def getDst_port(self):
		return self.dst_portp

	def getDst_ip(self):
		return self.dst_ipp

	def getDirection(self):
		return self.directionp

	def getAction(self):
		return self.actionp

	def getSrc_ip(self):
		return self.src_ipp

	def getIp_proto(self):
		return self.ip_protop

	def getComment(self):
		return self.commentp

	def getSrc_port(self):
		return self.src_portp

	def toString(self):
		return self.reprp
