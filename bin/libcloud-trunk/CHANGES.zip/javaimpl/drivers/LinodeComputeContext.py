from jlibcloud.driverSpecific.linode import LinodeComputeContext
from jlibcloud.driverSpecific.linode import LinodeNodeTemplateImpl

from javaimpl.ComputeContextImpl import ComputeContextImpl
from javaimpl.utils import wrap_listing
from javaimpl.utils import none_check

class LinodeComputeContextImpl(ComputeContextImpl, LinodeComputeContext):

	def __init__(self, builder):
		ComputeContextImpl.__init__(self, builder)

	def createNode(self, node_temp):
		kwargs = self._eval_template(node_temp)
		kwargs = self._parse_linode_template(node_temp, kwargs)
		self.conn.create_node(**kwargs)

	def _parse_linode_template(self, node_temp, kwargs):
		if node_temp.getLconfig():
			kwargs['lconfig'] =  node_temp.getLconfig()
		if node_temp.getExRsize():
			kwargs['ex_rsize'] =  node_temp.getExRsize()
		if node_temp.getExSwap():
			kwargs['ex_swap'] =  node_temp.getExSwap()
		if node_temp.getLroot():
			kwargs['lroot'] =  node_temp.getLroot()
		if node_temp.getExPrivate():
			kwargs['ex_private'] =  node_temp.getExPrivate()
		if node_temp.getExComment():
			kwargs['ex_comment'] =  node_temp.getExComment()
		if node_temp.getExPayment():
			kwargs['ex_payment'] =  node_temp.getExPayment()
		if node_temp.getLswap():
			kwargs['lswap'] =  node_temp.getLswap()
		if node_temp.getExKernel():
			kwargs['ex_kernel'] =  node_temp.getExKernel()
		return kwargs

	def getTemplateBuilder(self):
		return LinodeNodeTemplateImpl.newBuilder()

