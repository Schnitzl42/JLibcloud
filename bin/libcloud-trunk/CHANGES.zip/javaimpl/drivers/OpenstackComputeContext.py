from jlibcloud.driverSpecific.openstack import OpenStackComputeContext

from javaimpl.ComputeContextImpl import ComputeContextImpl
from javaimpl.utils import wrap_listing
from javaimpl.utils import none_check

class OpenStackComputeContextImpl(ComputeContextImpl, OpenStackComputeContext):

	def __init__(self, builder):
		ComputeContextImpl.__init__(self, builder)

	def exGetVolume(self, volumeId):
		from javaimpl.base.StorageVolumeImpl import StorageVolumeImpl
		return self.conn.ex_get_volume(volumeId)

	def exGetNodeDetails(self, node_id):
		'''
        Lists details of the specified server.

        :param       node_id: ID of the node which should be used
        :type        node_id: ``str``

        :rtype: :class:`Node`
		'''
		from javaimpl.base.NodeImpl import NodeImpl
		return NodeImpl(self.conn.ex_get_node_details(node_id))

	def exSoftRebootNode(self, node):
		'''
        Soft reboots the specified server

        :param      node:  node
        :type       node: :class:`Node`

        :rtype: ``bool``
		'''
		return self.conn.ex_soft_reboot_node(node.node)

	def exHardRebootNode(self, node):
		'''
        Hard reboots the specified server

        :param      node:  node
        :type       node: :class:`Node`

        :rtype: ``bool``
		'''
		return self.conn.ex_hard_reboot_node(node.node)

from jlibcloud.driverSpecific.openstack import OpenStack_1_0_ComputeContext
from jlibcloud.driverSpecific.openstack import OpenStack_1_0_NodeTemplateImpl

class OpenStack_1_0_ComputeContextImpl(OpenStackComputeContextImpl,
									 OpenStack_1_0_ComputeContext):

	def __init__(self, builder):
		OpenStackComputeContextImpl.__init__(self, builder)

	def createNode(self, node_temp):
		kwargs = self._eval_template(node_temp)
		kwargs = self._parse_openstack_1_0__template(node_temp, kwargs)
		self.conn.create_node(**kwargs)

	def _parse_openstack_1_0__template(self, node_temp, kwargs):
		if node_temp.getExFiles():
			kwargs['ex_files'] =  node_temp.getExFiles()
		if node_temp.getExMetadata():
			kwargs['ex_metadata'] =  node_temp.getExMetadata()
		if node_temp.getExSharedIpGroupId():
			kwargs['ex_shared_ip_group_id'] =  node_temp.getExSharedIpGroupId()
		return kwargs

	def exSetPassword(self, node, password):
		'''
        Sets the Node's root password.

        This will reboot the instance to complete the operation.

        :class:`Node.extra['password']` will be set to the new value if the
        operation was successful.

        :param      node: node to set password
        :type       node: :class:`Node`

        :param      password: new password.
        :type       password: ``str``

        :rtype: ``bool``
		'''
		return self.conn.ex_set_password(node.node, password)

	def exSetServerName(self, node, name):
		'''
        Sets the Node's name.

        This will reboot the instance to complete the operation.

        :param      node: node to set name
        :type       node: :class:`Node`

        :param      name: new name
        :type       name: ``str``

        :rtype: ``bool``
		'''
		return self.conn.ex_set_server_name(node.node, name)

	def exResize(self, node, size):
		'''
        Change an existing server flavor / scale the server up or down.

        :param      node: node to resize.
        :type       node: :class:`Node`

        :param      size: new size.
        :type       size: :class:`NodeSize`

        :rtype: ``bool``
		'''
		return self.conn.ex_resize(node.node, size.size)

	def exConfirmResize(self, node):
		'''
        Confirm a resize request which is currently in progress. If a resize
        request is not explicitly confirmed or reverted it's automatically
        confirmed after 24 hours.

        For more info refer to the API documentation: http://goo.gl/zjFI1

        :param      node: node for which the resize request will be confirmed.
        :type       node: :class:`Node`

        :rtype: ``bool``
		'''
		return self.conn.ex_confirm_resize(node.node)

	def exRevertResize(self, node):
		'''
        Revert a resize request which is currently in progress.
        All resizes are automatically confirmed after 24 hours if they have
        not already been confirmed explicitly or reverted.

        For more info refer to the API documentation: http://goo.gl/AizBu

        :param      node: node for which the resize request will be reverted.
        :type       node: :class:`Node`

        :rtype: ``bool``
		'''
		return self.conn.ex_revert_resize(node.node)

	def exRebuild(self, node_id, image_id):
		'''
        Rebuilds the specified server.

        :param       node_id: ID of the node which should be used
        :type        node_id: ``str``

        :param       image_id: ID of the image which should be used
        :type        image_id: ``str``

        :rtype: ``bool``
		'''
		return self.conn.ex_rebuild(node_id, image_id)

	def exCreateIpGroup(self, group_name, node_id=None):
		'''
        Creates a shared IP group.

        :param       group_name:  group name which should be used
        :type        group_name: ``str``

        :param       node_id: ID of the node which should be used
        :type        node_id: ``str``

        :rtype: ``bool``
		'''
		return self.conn.ex_create_ip_group(group_name, node_id)

	def exListIpGroups(self, details=False):
		'''
        Lists IDs and names for shared IP groups.
        If details lists all details for shared IP groups.

        :param       details: True if details is required
        :type        details: ``bool``

        :rtype: ``list`` of :class:`OpenStack_1_0_SharedIpGroup`
		'''
		return wrap_listing(self.conn.ex_list_ip_groups(details), OpenStack_1_0_SharedIpGroupImpl)

	def exDeleteIpGroup(self, group_id):
		'''
        Deletes the specified shared IP group.

        :param       group_id:  group id which should be used
        :type        group_id: ``str``

        :rtype: ``bool``
		'''
		return self.conn.ex_delete_ip_group(group_id)

	def exShareIp(self, group_id, node_id, ip, configure_node=True):
		'''
        Shares an IP address to the specified server.

        :param       group_id:  group id which should be used
        :type        group_id: ``str``

        :param       node_id: ID of the node which should be used
        :type        node_id: ``str``

        :param       ip: ip which should be used
        :type        ip: ``str``

        :param       configure_node: configure node
        :type        configure_node: ``bool``

        :rtype: ``bool``
		'''
		return self.conn.ex_share_ip(group_id, node_id, ip, configure_node)

	def exUnshareIp(self, node_id, ip):
		'''
        Removes a shared IP address from the specified server.

        :param       node_id: ID of the node which should be used
        :type        node_id: ``str``

        :param       ip: ip which should be used
        :type        ip: ``str``

        :rtype: ``bool``
		'''
		return self.conn.ex_unshare_ip(node_id, ip)

	def exListIpAddresses(self, node_id):
		'''
        List all server addresses.

        :param       node_id: ID of the node which should be used
        :type        node_id: ``str``

        :rtype: :class:`OpenStack_1_0_NodeIpAddresses`
		'''
		return wrap_listing(self.conn.ex_list_ip_addresses(node_id), OpenStack_1_0_NodeIpAddressesImpl)

	def exLimits(self):
		'''
        Extra call to get account's limits, such as
        rates (for example amount of POST requests per day)
        and absolute limits like total amount of available
        RAM to be used by servers.

        :return: dict with keys 'rate' and 'absolute'
        :rtype: ``dict``
		'''
		return self.conn.ex_limits()

	def exSaveImage(self, node, name):
		'''

        :param      node: node to use as a base for image
        :type       node: :class:`Node`

        :param      name: name for new image
        :type       name: ``str``

        :rtype: :class:`NodeImage`
		'''
		return NodeImageImpl(self.conn.ex_save_image(node.node, name))

	def exDeleteImage(self, image):
		'''

        :param      image: the image to be deleted
        :type       image: :class:`NodeImage`

        :rtype: ``bool``
		'''
		return self.conn.ex_delete_image(image.image)

	def getTemplateBuilder(self):
		return OpenStack_1_0_NodeTemplateImpl.newBuilder()
	
from jlibcloud.driverSpecific.openstack import OpenStack_1_1_ComputeContext
from jlibcloud.driverSpecific.openstack import OpenStack_1_1_NodeTemplateImpl

class OpenStack_1_1_ComputeContextImpl(OpenStack_1_0_ComputeContextImpl,
									 OpenStack_1_1_ComputeContext):

	def __init__(self, builder):
		OpenStack_1_0_ComputeContextImpl.__init__(self, builder)

	def createNode(self, node_temp):
		kwargs = self._eval_template(node_temp)
		kwargs = self._parse_openstack_1_1__template(node_temp, kwargs)
		self.conn.create_node(**kwargs)

	def _parse_openstack_1_1__template(self, node_temp, kwargs):
		if node_temp.getNetworks():
			kwargs['networks'] =  node_temp.getNetworks()
		if node_temp.getExFiles():
			kwargs['ex_files'] =  node_temp.getExFiles()
		if node_temp.getExSecurityGroups():
			kwargs['ex_security_groups'] =  node_temp.getExSecurityGroups()
		if node_temp.getExUserdata():
			kwargs['ex_userdata'] =  node_temp.getExUserdata()
		if node_temp.getExKeyname():
			kwargs['ex_keyname'] =  node_temp.getExKeyname()
		if node_temp.getExMetadata():
			kwargs['ex_metadata'] =  node_temp.getExMetadata()
		if node_temp.getExDiskConfig():
			kwargs['ex_disk_config'] =  node_temp.getExDiskConfig()
		return kwargs

	def exSetPassword(self, node, password):
		'''
        Changes the administrator password for a specified server.

        :param      node: Node to rebuild.
        :type       node: :class:`Node`

        :param      password: The administrator password.
        :type       password: ``str``

        :rtype: ``bool``
		'''
		return self.conn.ex_set_password(node.node, password)

	def exRebuild(self, node, image, **kwargs):
		'''
        Rebuild a Node.

        :param      node: Node to rebuild.
        :type       node: :class:`Node`

        :param      image: New image to use.
        :type       image: :class:`NodeImage`

        :keyword    ex_metadata: Key/Value metadata to associate with a node
        :type       ex_metadata: ``dict``

        :keyword    ex_files:   File Path => File contents to create on
                                the no  de
        :type       ex_files:   ``dict``

        :keyword    ex_keyname:  Name of existing public key to inject into
                                 instance
        :type       ex_keyname:  ``str``

        :keyword    ex_userdata: String containing user data
                                 see
                                 https://help.ubuntu.com/community/CloudInit
        :type       ex_userdata: ``str``

        :keyword    ex_security_groups: List of security groups to assign to
                                        the node
        :type       ex_security_groups: ``list`` of
                                       :class:`OpenStackSecurityGroup`

        :keyword    ex_disk_config: Name of the disk configuration.
                                    Can be either ``AUTO`` or ``MANUAL``.
        :type       ex_disk_config: ``str``

        :rtype: ``bool``
		'''
		return self.conn.ex_rebuild(node.node, image.image, **kwargs)

	def exResize(self, node, size):
		'''
        Change a node size.

        :param      node: Node to resize.
        :type       node: :class:`Node`

        :type       size: :class:`NodeSize`
        :param      size: New size to use.

        :rtype: ``bool``
		'''
		return self.conn.ex_resize(node.node, size.size)

	def exConfirmResize(self, node):
		'''
        Confirms a pending resize action.

        :param      node: Node to resize.
        :type       node: :class:`Node`

        :rtype: ``bool``
		'''
		return self.conn.ex_confirm_resize(node.node)

	def exRevertResize(self, node):
		'''
        Cancels and reverts a pending resize action.

        :param      node: Node to resize.
        :type       node: :class:`Node`

        :rtype: ``bool``
		'''
		return self.conn.ex_revert_resize(node.node)

	def exSaveImage(self, node, name, metadata=None):
		'''
        Creates a new image.

        :param      node: Node
        :type       node: :class:`Node`

        :param      name: The name for the new image.
        :type       name: ``str``

        :param      metadata: Key and value pairs for metadata.
        :type       metadata: ``dict``

        :rtype: :class:`NodeImage`
		'''
		from javaimpl.base.NodeImageImpl import NodeImageImpl
		return NodeImageImpl(self.conn.ex_save_image(node.node, name, metadata))

	def exSetServerName(self, node, name):
		'''
        Sets the Node's name.

        :param      node: Node
        :type       node: :class:`Node`

        :param      name: The name of the server.
        :type       name: ``str``

        :rtype: :class:`Node`
		'''
		return self.conn.ex_set_server_name(node.node, name) != None

	def exGetMetadata(self, node):
		'''
        Get a Node's metadata.

        :param      node: Node
        :type       node: :class:`Node`

        :return: Key/Value metadata associated with node.
        :rtype: ``dict``
		'''
		return self.conn.ex_get_metadata(node.node)

	def exSetMetadata(self, node, metadata):
		'''
        Sets the Node's metadata.

        :param      node: Node
        :type       node: :class:`Node`

        :param      metadata: Key/Value metadata to associate with a node
        :type       metadata: ``dict``

        :rtype: ``dict``
		'''
		return self.conn.ex_set_metadata(node.node, metadata)

	def exUpdateNode(self, node, **node_updates):
		'''
        Update the Node's editable attributes.  The OpenStack API currently
        supports editing name and IPv4/IPv6 access addresses.

        The driver currently only supports updating the node name.

        :param      node: Node
        :type       node: :class:`Node`

        :keyword    name:   New name for the server
        :type       name:   ``str``

        :rtype: :class:`Node`
		'''
		return self.conn.ex_update_node(node.node, **node_updates)

	def exListNetworks(self):
		'''
        Get a list of Networks that are available.

        :rtype: ``list`` of :class:`OpenStackNetwork`
		'''
		return wrap_listing(self.conn.ex_list_networks(), OpenStackNetworkImpl)

	def exCreateNetwork(self, name, cidr):
		'''
        Create a new Network

        :param name: Name of network which should be used
        :type name: ``str``

        :param cidr: cidr of network which should be used
        :type cidr: ``str``

        :rtype: :class:`OpenStackNetwork`
		'''
		return OpenStackNetworkImpl(self.conn.ex_create_network(name, cidr))

	def exDeleteNetwork(self, network):
		'''
        Get a list of NodeNetorks that are available.

        :param network: Network which should be used
        :type network: :class:`OpenStackNetwork`

        :rtype: ``bool``
		'''
		return self.conn.ex_delete_network(network.obj)

	def exGetConsoleOutput(self, node, length=None):
		'''
        Get console output

        :param      node: node
        :type       node: :class:`Node`

        :param      length: Optional number of lines to fetch from the
                            console log
        :type       length: ``int``

        :return: Dictionary with the output
        :rtype: ``dict``
		'''
		return self.conn.ex_get_console_output(node.node, length)

	def exListSecurityGroups(self):
		'''
        Get a list of Security Groups that are available.

        :rtype: ``list`` of :class:`OpenStackSecurityGroup`
		'''
		return wrap_listing(self.conn.ex_list_security_groups(), OpenStackSecurityGroupImpl)

	def exGetNodeSecurityGroups(self, node):
		'''
        Get Security Groups of the specified server.

        :rtype: ``list`` of :class:`OpenStackSecurityGroup`
		'''
		return wrap_listing(self.conn.ex_get_node_security_groups(node.node),
						OpenStackSecurityGroupImpl)

	def exCreateSecurityGroup(self, name, description):
		'''
        Create a new Security Group

        :param name: Name of the new Security Group
        :type  name: ``str``

        :param description: Description of the new Security Group
        :type  description: ``str``

        :rtype: :class:`OpenStackSecurityGroup`
		'''
		return OpenStackSecurityGroupImpl(self.conn.ex_create_security_group(name, description))

	def exDeleteSecurityGroup(self, security_group):
		'''
        Delete a Security Group.

        :param security_group: Security Group should be deleted
        :type  security_group: :class:`OpenStackSecurityGroup`

        :rtype: ``bool``
		'''
		return self.conn.ex_delete_security_group(security_group.obj)

	def exCreateSecurityGroupRule(self, security_group, ip_protocol,
                                      from_port, to_port, cidr=None,
                                      source_security_group=None):

		'''
        Create a new Rule in a Security Group

        :param security_group: Security Group in which to add the rule
        :type  security_group: :class:`OpenStackSecurityGroup`

        :param ip_protocol: Protocol to which this rule applies
                            Examples: tcp, udp, ...
        :type  ip_protocol: ``str``

        :param from_port: First port of the port range
        :type  from_port: ``int``

        :param to_port: Last port of the port range
        :type  to_port: ``int``

        :param cidr: CIDR notation of the source IP range for this rule
        :type  cidr: ``str``

        :param source_security_group: Existing Security Group to use as the
                                      source (instead of CIDR)
        :type  source_security_group: L{OpenStackSecurityGroup

        :rtype: :class:`OpenStackSecurityGroupRule`
		'''
		return OpenStackSecurityGroupRuleImpl(self.
											conn.ex_create_security_group_rule(security_group.obj, ip_protocol,
																			from_port, to_port, cidr, source_security_group))

	def exDeleteSecurityGroupRule(self, rule):
		'''
        Delete a Rule from a Security Group.

        :param rule: Rule should be deleted
        :type  rule: :class:`OpenStackSecurityGroupRule`

        :rtype: ``bool``
		'''
		return self.conn.ex_delete_security_group_rule(rule.obj)

	def exListKeypairs(self):
		'''
        Get a list of KeyPairs that are available.

        :rtype: ``list`` of :class:`OpenStackKeyPair`
		'''
		return wrap_listing(self.conn.ex_list_keypairs(), OpenStackKeyPairImpl)

	def exCreateKeypair(self, name):
		'''
        Create a new KeyPair

        :param name: Name of the new KeyPair
        :type  name: ``str``

        :rtype: :class:`OpenStackKeyPair`
		'''
		return OpenStackKeyPairImpl(self.conn.ex_create_keypair(name))

	def exImportKeypair(self, name, keyfile):
		'''
        Import a KeyPair from a file

        :param name: Name of the new KeyPair
        :type  name: ``str``

        :param keyfile: Path to the public key file (in OpenSSH format)
        :type  keyfile: ``str``

        :rtype: :class:`OpenStackKeyPair`
		'''
		return OpenStackKeyPairImpl(self.conn.ex_import_keypair(name, keyfile))

	def exImportKeypairFromString(self, name, key_material):
		'''
        Import a KeyPair from a string

        :param name: Name of the new KeyPair
        :type  name: ``str``

        :param key_material: Public key (in OpenSSH format)
        :type  key_material: ``str``

        :rtype: :class:`OpenStackKeyPair`
		'''
		return OpenStackKeyPairImpl(self.conn.ex_import_keypair_from_string(name, key_material))

	def exDeleteKeypair(self, keypair):
		'''
        Delete a KeyPair.

        :param keypair: KeyPair to delete
        :type  keypair: :class:`OpenStackKeyPair`

        :rtype: ``bool``
		'''
		return self.conn.ex_delete_keypair(keypair.obj)

	def exGetSize(self, size_id):
		'''
        Get a NodeSize

        :param      size_id: ID of the size which should be used
        :type       size_id: ``str``

        :rtype: :class:`NodeSize`
		'''
		from javaimpl.base.NodeSizeImpl import NodeSizeImpl
		return NodeSizeImpl(self.conn.ex_get_size(size_id))

	def exGetImage(self, image_id):
		'''
        Get a NodeImage

        :param      image_id: ID of the image which should be used
        :type       image_id: ``str``

        :rtype: :class:`NodeImage`
		'''
		from javaimpl.base.NodeImageImpl import NodeImageImpl
		return NodeImageImpl(self.conn.ex_get_image(image_id))

	def exDeleteImage(self, image):
		'''
        Delete a NodeImage

        :param      image: image witch should be used
        :type       image: :class:`NodeImage`

        :rtype: ``bool``
		'''
		return self.conn.ex_delete_image(image.image)

	def exRescue(self, node, password=None):
		'''
        Rescue a node

        :param      node: node
        :type       node: :class:`Node`

        :param      password: password
        :type       password: ``str``

        :rtype: :class:`Node`
		'''
		from javaimpl.base.NodeImpl import NodeImpl
		return NodeImpl(self.conn.ex_rescue(node.node, password))

	def exUnrescue(self, node):
		'''
        Unrescue a node

        :param      node: node
        :type       node: :class:`Node`

        :rtype: ``bool``
		'''
		return self.conn.ex_unrescue(node.node)

	def exListFloatingIpPools(self):
		'''
        List available floating IP pools

        :rtype: ``list`` of :class:`OpenStack_1_1_FloatingIpPool`
		'''
		return wrap_listing(self.conn.ex_list_floating_ip_pools(),
						OpenStack_1_1_FloatingIpPoolImpl)

	def exAttachFloatingIpToNode(self, node, ip):
		'''
        Attach the floating IP to the node

        :param      node: node
        :type       node: :class:`Node`

        :param      ip: floating IP to attach
        :type       ip: ``str`` or :class:`OpenStack_1_1_FloatingIpAddress`

        :rtype: ``bool``
		'''
		return self.conn.ex_attach_floating_ip_to_node(node.node, ip)

	def exDetachFloatingIpFromNode(self, node, ip):
		'''
        Detach the floating IP from the node

        :param      node: node
        :type       node: :class:`Node`

        :param      ip: floating IP to remove
        :type       ip: ``str`` or :class:`OpenStack_1_1_FloatingIpAddress`

        :rtype: ``bool``
		'''
		return self.conn.ex_detach_floating_ip_from_node(node.node, ip)

	def exGetMetadataForNode(self, node):
		'''
        Return the metadata associated with the node.

        :param      node: Node instance
        :type       node: :class:`Node`

        :return: A dictionary or other mapping of strings to strings,
                 associating tag names with tag values.
        :type tags: ``dict``
		'''
		return self.conn.ex_get_metadata_for_node(node.node)

	def exPauseNode(self, node):
		return self.conn.ex_pause_node(node.node)

	def exUnpauseNode(self, node):
		return self.conn.ex_unpause_node(node.node)

	def exSuspendNode(self, node):
		return self.conn.ex_suspend_node(node.node)

	def exResumeNode(self, node):
		return self.conn.ex_resume_node(node.node)

	def getTemplateBuilder(self):
		return OpenStack_1_1_NodeTemplateImpl.newBuilder()

from jlibcloud.driverSpecific.openstack import OpenStackNodeSize as JOpenStackNodeSize
from javaimpl.base.NodeSizeImpl import NodeSizeImpl

class OpenStackNodeSizeImpl(NodeSizeImpl, JOpenStackNodeSize):

	def __init__(self, obj):
		NodeSizeImpl.__init__(self, obj)
		if hasattr(obj, 'vcpus'):
			self.vcpusp = none_check(obj.vcpus, '')
		else:
			self.vcpusp = ''
		if hasattr(obj, '__repr__()'):
			self.reprp = obj.__repr__()
		else:
			self.reprp = ''

	def getVcpus(self):
		return self.vcpusp

	def toString(self):
		return self.reprp

from jlibcloud.driverSpecific.openstack import OpenStack_1_0_SharedIpGroup as JOpenStack_1_0_SharedIpGroup

class OpenStack_1_0_SharedIpGroupImpl(JOpenStack_1_0_SharedIpGroup):

	def __init__(self, obj):
		self.obj = obj
		if hasattr(obj, 'id'):
			self.idp = none_check(obj.id, '')
		else:
			self.idp = ''
		if hasattr(obj, 'servers'):
			self.serversp = none_check(obj.servers, '')
		else:
			self.serversp = ''
		if hasattr(obj, 'name'):
			self.namep = none_check(obj.name, '')
		else:
			self.namep = ''

	def getId(self):
		return self.idp

	def getServers(self):
		return self.serversp

	def getName(self):
		return self.namep

from jlibcloud.driverSpecific.openstack import OpenStack_1_0_NodeIpAddresses as JOpenStack_1_0_NodeIpAddresses

class OpenStack_1_0_NodeIpAddressesImpl(JOpenStack_1_0_NodeIpAddresses):

	def __init__(self, obj):
		self.obj = obj
		if hasattr(obj, 'public_addresses'):
			self.public_addressesp = none_check(obj.public_addresses, '')
		else:
			self.public_addressesp = ''
		if hasattr(obj, 'private_addresses'):
			self.private_addressesp = none_check(obj.private_addresses, '')
		else:
			self.private_addressesp = ''

	def getPublicAddresses(self):
		return self.public_addressesp

	def getPrivateAddresses(self):
		return self.private_addressesp

from jlibcloud.driverSpecific.openstack import OpenStackNetwork as JOpenStackNetwork

class OpenStackNetworkImpl(JOpenStackNetwork):

	def __init__(self, obj):
		self.obj = obj
		if hasattr(obj, 'id'):
			self.idp = none_check(obj.id, '')
		else:
			self.idp = ''
		if hasattr(obj, 'extra'):
			self.extrap = obj.extra
		else:
			self.extrap = {}
		if hasattr(obj, 'name'):
			self.namep = none_check(obj.name, '')
		else:
			self.namep = ''
		if hasattr(obj, 'cidr'):
			self.cidrp = none_check(obj.cidr, '')
		else:
			self.cidrp = ''
		if hasattr(obj, '__repr__()'):
			self.reprp = obj.__repr__()
		else:
			self.reprp = ''

	def getId(self):
		return self.idp

	def getExtra(self):
		return self.extrap

	def getName(self):
		return self.namep

	def getCidr(self):
		return self.cidrp

	def toString(self):
		return self.reprp

from jlibcloud.driverSpecific.openstack import OpenStackSecurityGroup as JOpenStackSecurityGroup

class OpenStackSecurityGroupImpl(JOpenStackSecurityGroup):

	def __init__(self, obj):
		self.obj = obj
		if hasattr(obj, 'id'):
			self.idp = none_check(obj.id, '')
		else:
			self.idp = ''
		if hasattr(obj, 'extra'):
			self.extrap = obj.extra
		else:
			self.extrap = {}
		if hasattr(obj, 'description'):
			self.descriptionp = none_check(obj.description, '')
		else:
			self.descriptionp = ''
		if hasattr(obj, 'name'):
			self.namep = none_check(obj.name, '')
		else:
			self.namep = ''
		if hasattr(obj, 'tenant_id'):
			self.tenant_idp = none_check(obj.tenant_id, '')
		else:
			self.tenant_idp = ''
		if hasattr(obj, 'rules'):
			self.rulesp = obj.rules
		else:
			self.rulesp = []
		if hasattr(obj, '__repr__()'):
			self.reprp = obj.__repr__()
		else:
			self.reprp = ''

	def getId(self):
		return self.idp

	def getExtra(self):
		return self.extrap

	def getDescription(self):
		return self.descriptionp

	def getName(self):
		return self.namep

	def getTenantId(self):
		return self.tenant_idp

	def getRules(self):
		return self.rulesp

	def toString(self):
		return self.reprp

from jlibcloud.driverSpecific.openstack import OpenStackSecurityGroupRule as JOpenStackSecurityGroupRule

class OpenStackSecurityGroupRuleImpl(JOpenStackSecurityGroupRule):

	def __init__(self, obj):
		self.obj = obj
		if hasattr(obj, 'to_port'):
			self.to_portp = obj.to_port
		else:
			self.to_portp = None
		if hasattr(obj, 'id'):
			self.idp = none_check(obj.id, '')
		else:
			self.idp = ''
		if hasattr(obj, 'from_port'):
			self.from_portp = obj.from_port
		else:
			self.from_portp = None
		if hasattr(obj, 'ip_protocol'):
			self.ip_protocolp = none_check(obj.ip_protocol, '')
		else:
			self.ip_protocolp = ''
		if hasattr(obj, 'extra'):
			self.extrap = obj.extra
		else:
			self.extrap = {}
		if hasattr(obj, 'ip_range'):
			self.ip_rangep = none_check(obj.ip_range, '')
		else:
			self.ip_rangep = ''
		if hasattr(obj, 'tenant_id'):
			self.tenant_idp = none_check(obj.tenant_id, '')
		else:
			self.tenant_idp = ''
		if hasattr(obj, 'group'):
			self.groupp = obj.group
		else:
			self.groupp = {}
		if hasattr(obj, 'parent_group_id'):
			self.parent_group_idp = none_check(obj.parent_group_id, '')
		else:
			self.parent_group_idp = ''
		if hasattr(obj, '__repr__()'):
			self.reprp = obj.__repr__()
		else:
			self.reprp = ''

	def getToPort(self):
		return self.to_portp

	def getId(self):
		return self.idp

	def getFromPort(self):
		return self.from_portp

	def getIpProtocol(self):
		return self.ip_protocolp

	def getExtra(self):
		return self.extrap

	def getIpRange(self):
		return self.ip_rangep

	def getTenantId(self):
		return self.tenant_idp
	
	def getGroup(self):
		return self.groupp

	def getParentGroupId(self):
		return self.parent_group_idp

	def toString(self):
		return self.reprp

from jlibcloud.driverSpecific.openstack import OpenStackKeyPair as JOpenStackKeyPair

class OpenStackKeyPairImpl(JOpenStackKeyPair):

	def __init__(self, obj):
		self.obj = obj
		if hasattr(obj, 'fingerprint'):
			self.fingerprintp = none_check(obj.fingerprint, '')
		else:
			self.fingerprintp = ''
		if hasattr(obj, 'extra'):
			self.extrap = obj.extra
		else:
			self.extrap = {}
		if hasattr(obj, 'private_key'):
			self.private_keyp = none_check(obj.private_key, '')
		else:
			self.private_keyp = ''
		if hasattr(obj, 'name'):
			self.namep = none_check(obj.name, '')
		else:
			self.namep = ''
		if hasattr(obj, 'public_key'):
			self.public_keyp = none_check(obj.public_key, '')
		else:
			self.public_keyp = ''
		if hasattr(obj, '__repr__()'):
			self.reprp = obj.__repr__()
		else:
			self.reprp = ''

	def getFingerprint(self):
		return self.fingerprintp

	def getExtra(self):
		return self.extrap

	def getPrivate_Key(self):
		return self.private_keyp

	def getName(self):
		return self.namep

	def getPublicKey(self):
		return self.public_keyp

	def toString(self):
		return self.reprp

from jlibcloud.driverSpecific.openstack import OpenStack_1_1_FloatingIpPool as JOpenStack_1_1_FloatingIpPool

class OpenStack_1_1_FloatingIpPoolImpl(JOpenStack_1_1_FloatingIpPool):

	def __init__(self, obj):
		self.obj = obj
		if hasattr(obj, 'name'):
			self.namep = none_check(obj.name, '')
		else:
			self.namep = ''
		if hasattr(obj, '__repr__()'):
			self.reprp = obj.__repr__()
		else:
			self.reprp = ''

	def getName(self):
		return self.namep

	def toString(self):
		return self.reprp

	def listFloatingIps(self):
		'''
        List floating IPs in the pool

        :rtype: ``list`` of :class:`OpenStack_1_1_FloatingIpAddress`
		'''
		return wrap_listing(self.conn.list_floating_ips(), OpenStack_1_1_FloatingIpAddressImpl)

	def getFloatingIp(self, ip):
		'''
        Get specified floating IP from the pool

        :param      ip: floating IP to remove
        :type       ip: ``str``

        :rtype: :class:`OpenStack_1_1_FloatingIpAddress`
		'''
		return OpenStack_1_1_FloatingIpAddressImpl(self.conn.get_floating_ip(ip))

	def createFloatingIp(self):
		'''
        Create new floating IP in the pool

        :rtype: :class:`OpenStack_1_1_FloatingIpAddress`
		'''
		return OpenStack_1_1_FloatingIpAddressImpl(self.conn.create_floating_ip())

	def deleteFloatingIp(self, ip):
		'''
        Delete specified floating IP from the pool

        :param      ip: floating IP to remove
        :type       ip::class:`OpenStack_1_1_FloatingIpAddress`

        :rtype: ``bool``
		'''
		return self.conn.delete_floating_ip(ip.obj)

from jlibcloud.driverSpecific.openstack import OpenStack_1_1_FloatingIpAddress as JOpenStack_1_1_FloatingIpAddress

class OpenStack_1_1_FloatingIpAddressImpl(JOpenStack_1_1_FloatingIpAddress):

	def __init__(self, obj):
		self.obj = obj
		if hasattr(obj, 'id'):
			self.idp = none_check(obj.id, '')
		else:
			self.idp = ''
		if hasattr(obj, 'ip_address'):
			self.ip_addressp = none_check(obj.ip_address, '')
		else:
			self.ip_addressp = ''
		if hasattr(obj, 'pool'):
			self.poolp = none_check(obj.pool, '')
		else:
			self.poolp = ''
		if hasattr(obj, 'node_id'):
			self.node_idp = none_check(obj.node_id, '')
		else:
			self.node_idp = ''
		if hasattr(obj, '__repr__()'):
			self.reprp = obj.__repr__()
		else:
			self.reprp = ''

	def getId(self):
		return self.idp

	def getIp_address(self):
		return self.ip_addressp

	def getPool(self):
		return self.poolp

	def getNode_id(self):
		return self.node_idp

	def toString(self):
		return self.reprp

	def delete(self):
		'''
        Delete this floating IP

        :rtype: ``bool``
		'''
		return self.obj.delete()

