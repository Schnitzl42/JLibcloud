from jlibcloud.driverSpecific.libvirt_driver import LibvirtComputeContext
from jlibcloud.driverSpecific.libvirt_driver import LibvirtNodeTemplateImpl

from javaimpl.ComputeContextImpl import ComputeContextImpl
from javaimpl.utils import wrap_listing
from javaimpl.utils import none_check

class LibvirtComputeContextImpl(ComputeContextImpl, LibvirtComputeContext):

	def __init__(self, builder):
		ComputeContextImpl.__init__(self, builder)

	def exStartNode(self, node):
		'''
        Start a stopped node.

        :param  node: Node which should be used
        :type   node: :class:`Node`

        :rtype: ``bool``
		'''
		return self.conn.ex_start_node(node.node)

	def exShutdownNode(self, node):
		'''
        Shutdown a running node.

        Note: Usually this will result in sending an ACPI event to the node.

        :param  node: Node which should be used
        :type   node: :class:`Node`

        :rtype: ``bool``
		'''
		return self.conn.ex_shutdown_node(node.node)

	def exSuspendNode(self, node):
		'''
        Suspend a running node.

        :param  node: Node which should be used
        :type   node: :class:`Node`

        :rtype: ``bool``
		'''
		return self.conn.ex_suspend_node(node.node)

	def exResumeNode(self, node):
		'''
        Resume a suspended node.

        :param  node: Node which should be used
        :type   node: :class:`Node`

        :rtype: ``bool``
		'''
		return self.conn.ex_resume_node(node.node)

	def exTakeNodeScreenshot(self, node, directory, screen=0):
		'''
        Take a screenshot of a monitoring of a running instance.

        :param node: Node to take the screenshot of.
        :type node: :class:`libcloud.compute.base.Node`

        :param directory: Path where the screenshot will be saved.
        :type directory: ``str``

        :param screen: ID of the monitor to take the screenshot of.
        :type screen: ``int``

        :return: Full path where the screenshot has been saved.
        :rtype: ``str``
		'''
		return self.conn.ex_take_node_screenshot(node.node, directory, screen)

	def exGetHypervisorHostname(self):
		'''
        Return a system hostname on which the hypervisor is running.
		'''
		return self.conn.ex_get_hypervisor_hostname()

	def exGetHypervisorSysinfo(self):
		'''
        Retrieve hypervisor system information.

        :rtype: ``dict``
		'''
		return self.conn.ex_get_hypervisor_sysinfo()

