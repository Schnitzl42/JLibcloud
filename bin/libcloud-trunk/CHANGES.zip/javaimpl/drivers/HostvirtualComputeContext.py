from jlibcloud.driverSpecific.hostvirtual import HostVirtualComputeContext
from jlibcloud.wrapperInterfacesImpl import NodeTemplateImpl

from javaimpl.ComputeContextImpl import ComputeContextImpl
from javaimpl.utils import wrap_listing
from javaimpl.utils import none_check

class HostVirtualComputeContextImpl(ComputeContextImpl, HostVirtualComputeContext):

	def __init__(self, builder):
		ComputeContextImpl.__init__(self, builder)

	def exGetNode(self, node_id):
		'''
        Get a single node.

        :param      node_id: id of the node that we need the node object for
        :type       node_id: ``str``

        :rtype: :class:`Node`
		'''
		from javaimpl.base.NodeImpl import NodeImpl
		return NodeImpl(self.conn.ex_get_node(node_id))

	def exStopNode(self, node):
		'''
        Stop a node.

        :param      node: Node which should be used
        :type       node: :class:`Node`

        :rtype: ``bool``
		'''
		return self.conn.ex_stop_node(node.node)

	def exStartNode(self, node):
		'''
        Start a node.

        :param      node: Node which should be used
        :type       node: :class:`Node`

        :rtype: ``bool``
		'''
		return self.conn.ex_start_node(node.node)

	def exProvisionNode(self, **kwargs):
		'''
        Provision a server on a VR package and get it booted

        :keyword node: node which should be used
        :type    node: :class:`Node`

        :keyword image: The distribution to deploy on your server (mandatory)
        :type    image: :class:`NodeImage`

        :keyword auth: an SSH key or root password (mandatory)
        :type    auth: :class:`NodeAuthSSHKey` or :class:`NodeAuthPassword`

        :keyword location: which datacenter to create the server in
        :type    location: :class:`NodeLocation`

        :return: Node representing the newly built server
        :rtype: :class:`Node`
		'''
		return self.conn.ex_provision_node(**kwargs)

	def exDeleteNode(self, node):
		'''
        Delete a node.

        :param      node: Node which should be used
        :type       node: :class:`Node`

        :rtype: ``bool``
		'''
		return self.conn.ex_delete_node(node.node)

	def getTemplateBuilder(self):
		return NodeTemplateImpl.newBuilder()

