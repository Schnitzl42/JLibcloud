from jlibcloud.driverSpecific.ibm_sce import IBMComputeContext
from jlibcloud.driverSpecific.ibm_sce import IBMNodeTemplateImpl

from javaimpl.ComputeContextImpl import ComputeContextImpl
from javaimpl.utils import wrap_listing
from javaimpl.utils import none_check

class IBMComputeContextImpl(ComputeContextImpl, IBMComputeContext):

	def __init__(self, builder):
		ComputeContextImpl.__init__(self, builder)

	def createNode(self, node_temp):
		kwargs = self._eval_template(node_temp)
		kwargs = self._parse_ibm_template(node_temp, kwargs)
		self.conn.create_node(**kwargs)

	def _parse_ibm_template(self, node_temp, kwargs):
		if node_temp.getExConfigurationData():
			kwargs['ex_configurationData'] =  node_temp.getExConfigurationData()
		if node_temp.getAuthentication():
			from libcloud.compute.base import NodeAuthSSHKey
			kwargs['auth'] = NodeAuthSSHKey(node_temp.getAuthentication())
		return kwargs

	def exDestroyImage(self, image):
		'''
        Destroys an image.

        :param      image: Image to be destroyed
        :type       image: :class:`NodeImage`

        :return: ``bool``
		'''
		return self.conn.ex_destroy_image(image.image)

	def exListStorageOfferings(self):
		'''
        List the storage center offerings

        :rtype: ``list`` of :class:`VolumeOffering`
		'''
		return wrap_listing(self.conn.ex_list_storage_offerings(), VolumeOfferingImpl)

	def exAllocateAddress(self, location_id, offering_id, vlan_id=None):
		'''
        Allocate a new reserved IP address

        :param      location_id: Target data center
        :type       location_id: ``str``

        :param      offering_id: Offering ID for address to create
        :type       offering_id: ``str``

        :param      vlan_id: ID of target VLAN
        :type       vlan_id: ``str``

        :return: :class:`Address` object
        :rtype: :class:`Address`
		'''
		return self.conn.ex_allocate_address(location_id, offering_id, vlan_id)

	def exListAddresses(self, resource_id=None):
		'''
        List the reserved IP addresses

        :param      resource_id: If this is supplied only a single address will
         be returned (optional)
        :type       resource_id: ``str``

        :rtype: ``list`` of :class:`Address`
		'''
		return wrap_listing(self.conn.ex_list_addresses(resource_id), AddressImpl)

	def exCopyTo(self, image, volume):
		'''
        Copies a node image to a storage volume

        :param      image: source image to copy
        :type       image: :class:`NodeImage`

        :param      volume: Target storage volume to copy to
        :type       volume: :class:`StorageVolume`

        :return: ``bool`` The success of the operation
        :rtype: ``bool``
		'''
		return self.conn.ex_copy_to(image.image, volume.volume)

	def exDeleteAddress(self, resource_id):
		'''
        Delete a reserved IP address

        :param      resource_id: The address to delete (required)
        :type       resource_id: ``str``

        :rtype: ``bool``
		'''
		return self.conn.ex_delete_address(resource_id)

	def exWaitStorageState(self, volume, state=VolumeState.DETACHED,
                              wait_period=60, timeout=1200):
		'''
        Block until storage volume state changes to the given value

        :param      volume: Storage volume.
        :type       volume: :class:`StorageVolume`

        :param      state: The target state to wait for
        :type       state: ``int``

        :param      wait_period: How many seconds to between each loop
                                 iteration (default is 3)
        :type       wait_period: ``int``

        :param      timeout: How many seconds to wait before timing out
                             (default is 1200)
        :type       timeout: ``int``

        :rtype: :class:`StorageVolume`
		'''
		return StorageVolumeImpl(self.
								conn.ex_wait_storage_state(volume.volume, state,
														wait_period, timeout))

	def getTemplateBuilder(self):
		return IBMNodeTemplateImpl.newBuilder()

from jlibcloud.driverSpecific.ibm_sce import IBMNodeLocation as JIBMNodeLocation
from javaimpl.base.NodeLocationImpl import NodeLocationImpl

class IBMNodeLocationImpl(JIBMNodeLocation):

	def __init__(self, obj):
		NodeLocationImpl.__init__(self, obj)
		if hasattr(obj, 'id'):
			self.idp = none_check(obj.id, '')
		else:
			self.idp = ''
		if hasattr(obj, 'name'):
			self.namep = none_check(obj.name, '')
		else:
			self.namep = ''
		if hasattr(obj, 'country'):
			self.countryp = none_check(obj.country, '')
		else:
			self.countryp = ''
		if hasattr(obj, 'extra'):
			self.extrap = obj.extra
		else:
			self.extrap = {}
		if hasattr(obj, '__repr__()'):
			self.reprp = obj.__repr__()
		else:
			self.reprp = ''
	
	def getId(self):
		return self.idp
	
	def getName(self):
		return self.namep

	def getCountry(self):
		return self.countryp
	
	def getExtra(self):
		return self.extrap

	def toString(self):
		return self.reprp

from jlibcloud.driverSpecific.ibm_sce import VolumeState as JVolumeState

class VolumeStateImpl(JVolumeState):

	def __init__(self, obj):
		self.conn = obj
		
from jlibcloud.driverSpecific.ibm_sce import VolumeOffering as JVolumeOffering

class VolumeOfferingImpl(JVolumeOffering):

	def __init__(self, obj):
		self.conn = obj
		if hasattr(obj, 'id'):
			self.idp = none_check(obj.id, '')
		else:
			self.idp = ''
		if hasattr(obj, 'location'):
			self.locationp = none_check(obj.location, '')
		else:
			self.locationp = ''
		if hasattr(obj, 'name'):
			self.namep = none_check(obj.name, '')
		else:
			self.namep = ''
		if hasattr(obj, 'extra'):
			self.extrap = obj.extra
		else:
			self.extrap = {}
		if hasattr(obj, '__repr__()'):
			self.reprp = obj.__repr__()
		else:
			self.reprp = ''

	def getId(self):
		return self.idp

	def getLocation(self):
		return self.locationp

	def getName(self):
		return self.namep
	
	def getExtra(self):
		return self.extrap

	def toString(self):
		return self.reprp

from jlibcloud.driverSpecific.ibm_sce import Address as JAddress

class AddressImpl(JAddress):

	def __init__(self, obj):
		self.conn = obj
		if hasattr(obj, 'id'):
			self.idp = none_check(obj.id, '')
		else:
			self.idp = ''
		if hasattr(obj, 'state'):
			self.statep = none_check(obj.state, '')
		else:
			self.statep = ''
		if hasattr(obj, 'options'):
			self.optionsp = none_check(obj.options, '')
		else:
			self.optionsp = ''
		if hasattr(obj, 'ip'):
			self.ipp = none_check(obj.ip, '')
		else:
			self.ipp = ''
		if hasattr(obj, '__repr__()'):
			self.reprp = obj.__repr__()
		else:
			self.reprp = ''

	def getId(self):
		return self.idp

	def getState(self):
		return self.statep

	def getOptions(self):
		return self.optionsp

	def getIp(self):
		return self.ipp

	def toString(self):
		return self.reprp
