'''
Created on 21.12.2013

@author: root
'''

from jlibcloud.driverSpecific.EC2 import EC2ComputeContext
from jlibcloud.driverSpecific.EC2 import EC2NodeTemplateImpl
from jlibcloud.driverSpecific.EC2 import EC2Network as JEC2Network
from jlibcloud.driverSpecific.EC2 import EC2NetworkSubnet as JEC2NetworkSubnet
from jlibcloud.driverSpecific.EC2 import EC2NetworkInterface as JEC2NetworkInterface


from javaimpl.utils import wrap_listing
from javaimpl.utils import none_check

import time
from libcloud.utils.xml import fixxpath, findtext, findattr, findall
from libcloud.compute.drivers.ec2 import NAMESPACE

class EC2NetworkImpl(JEC2Network):
    def __init__(self, ec2_network):
        self.ec2_network = ec2_network
        from libcloud.compute.drivers.ec2 import EC2Network
        if isinstance(ec2_network, EC2Network):
            self.pid = none_check(ec2_network.id, "")
            self.pname = none_check(ec2_network.name, "")
            self.pcidr_block = none_check(ec2_network.cidr_block, "")
            self.pextra = ec2_network.extra
            self.prepr = ec2_network.__repr__()
        else:
            self.pid = ""
            self.pname = ""
            self.pcidr_block = ""
            self.pextra = {}
            self.prepr = ""
            
    def getID(self):
        return self.pid
    
    def getName(self):
        return self.pname
    
    def getCidrBlock(self):
        return self.pcidr_block
    
    def getExtra(self):
        return self.pextra
    
    def toString(self):
        return self.prepr

class EC2NetworkInterfaceImpl(JEC2NetworkInterface):
    def __init__(self, ec2_network):
        self.ec2_network = ec2_network
        from libcloud.compute.drivers.ec2 import EC2NetworkInterface
        if isinstance(ec2_network, EC2NetworkInterface):
            self.pid = none_check(ec2_network.id, "")
            self.pname = none_check(ec2_network.name, "")
            self.pstate = ec2_network.state
            self.pextra = ec2_network.extra
            self.prepr = ec2_network.__repr__()
        else:
            self.pid = ""
            self.pname = ""
            self.pstate = -1
            self.pextra = {}
            self.prepr = ""
            
    def getID(self):
        return self.pid
    
    def getName(self):
        return self.pname
    
    def getState(self):
        return self.pcidr_block
    
    def getExtra(self):
        return self.pextra
    
    def toString(self):
        return self.prepr
    
class EC2NetworkSubnetImpl(JEC2NetworkSubnet):
    def __init__(self, ec2_network):
        self.ec2_network = ec2_network
        from libcloud.compute.drivers.ec2 import EC2NetworkSubnet
        if isinstance(ec2_network, EC2NetworkSubnet):
            self.pid = none_check(ec2_network.id, "")
            self.pname = none_check(ec2_network.name, "")
            self.pstate = ec2_network.state
            self.pextra = ec2_network.extra
            self.prepr = ec2_network.__repr__()
        else:
            self.pid = ""
            self.pname = ""
            self.pstate = -1
            self.pextra = {}
            self.prepr = ""
            
    def getID(self):
        return self.pid
    
    def getName(self):
        return self.pname
    
    def getState(self):
        return self.pcidr_block
    
    def getExtra(self):
        return self.pextra
    
    def toString(self):
        return self.prepr
    
from javaimpl.ComputeContextImpl import ComputeContextImpl

class EC2ComputeContextImpl(ComputeContextImpl, EC2ComputeContext):
    '''
    classdocs
    '''
    def __init__(self, builder):
        '''
        Constructor
        '''
        ComputeContextImpl.__init__(self, builder)
          
    def createNode(self, node_temp):
        kwargs = self._eval_template(node_temp)
        kwargs = self._parse_ec2_template(node_temp, kwargs)
        #normal or spot create
        spot_price = node_temp.getSpotPrice()
        if spot_price == None:
            instances = node_temp.getInstanceCount()
            if instances != None:
                kwargs["ex_mincount"] = instances
                kwargs["ex_maxcount"] = instances
            self.conn.create_node(**kwargs)
        else:
            kwargs['ex_price'] = spot_price
            kwargs['ex_instancecount'] = none_check(node_temp.getInstanceCount(), '1')
            self.conn.create_spot_node(**kwargs)
    
    #--------------------------------------------#
    # provider specific methods                  #
    #--------------------------------------------#
    def create_spot_node(self, **kwargs):
        """Create a new EC2 spot node

        Reference: http://bit.ly/8ZyPSy [docs.amazonwebservices.com]

        @inherits: L{NodeDriver.create_node}

        @keyword    ex_price: Maximum hourly price for any Spot Instance launched to fulfill the request
        @type       ex_price: C{str}
        
        @keyword    ex_instancecount: number of instances to launch
        @type       ex_instancecount: C{int}

        @keyword    ex_security_groups: Name of security group
        @type       ex_security_groups: C{str}

        @keyword    ex_keyname: The name of the key pair
        @type       ex_keyname: C{str}

        @keyword    ex_userdata: User data
        @type       ex_userdata: C{str}

        @keyword    ex_clienttoken: Unique identifier to ensure idempotency
        @type       ex_clienttoken: C{str}

        @keyword    ex_blockdevicemappings: C{list} of C{dict} block device
                    mappings. Example:
                    [{'DeviceName': '/dev/sdb', 'VirtualName': 'ephemeral0'}]
        @type       ex_blockdevicemappings: C{list} of C{dict}
        """
        image = kwargs["image"]
        size = kwargs["size"]
        price = kwargs["ex_price"]
        params = {
            'Action': 'RequestSpotInstances',
            'SpotPrice' : price,
            'LaunchSpecification.ImageId': image.id,
            'InstanceCount': kwargs.get('ex_instancecount', '1'),
            'LaunchSpecification.InstanceType': size.id
        }

        if 'ex_security_groups' in kwargs:
            if not isinstance(kwargs['ex_security_groups'], list):
                kwargs['ex_security_groups'] = [kwargs['ex_security_groups']]
            for sig in range(len(kwargs['ex_security_groups'])):
                params['LaunchSpecification.SecurityGroup.%d' % (sig + 1,)] =\
                    kwargs['ex_security_groups'][sig]

        if 'location' in kwargs:
            availability_zone = getattr(kwargs['location'],
                                        'availability_zone', None)
            if availability_zone:
                if availability_zone.region_name != self.region_name:
                    raise AttributeError('Invalid availability zone: %s'
                                         % (availability_zone.name))
                params['LaunchSpecification.Placement.AvailabilityZone'] = availability_zone.name

        if 'ex_keyname' in kwargs:
            params['LaunchSpecification.KeyName'] = kwargs['ex_keyname']

        if 'ex_userdata' in kwargs:
            params['LaunchSpecification.UserData'] = base64.b64encode(b(kwargs['ex_userdata']))\
                .decode('utf-8')

        #if 'ex_clienttoken' in kwargs:
        #   params['ClientToken'] = kwargs['ex_clienttoken']

        if 'ex_blockdevicemappings' in kwargs:
            for index, mapping in enumerate(kwargs['ex_blockdevicemappings']):
                params['LaunchSpecification.BlockDeviceMapping.%d.DeviceName' % (index + 1)] = \
                    mapping['DeviceName']
                params['LaunchSpecification.BlockDeviceMapping.%d.VirtualName' % (index + 1)] = \
                    mapping['VirtualName']

        #object - the RequestSpotInstancesResponse
        object = self.conn.connection.request(self.path, params=params).object
        #TODO: assign name tag to running spot nodes
        nodes = self.conn._to_nodes(object, 'spotInstanceRequestSet/item')
       
        for node in nodes:
            tags = {'Name': kwargs['name']}

            try:
                self.ex_create_tags(resource=node, tags=tags)
            except Exception:
                continue

            node.name = kwargs['name']
            node.extra.update({'tags': tags})

        if len(nodes) == 1:
            return nodes[0]
        else:
            return nodes
            
    def waitUntilRunning(self, nodes, waitPeriodSeconds=5, timeoutSeconds=600):
        '''waits until the given nodes are accesible via ssh.
            invokes first ComputeContextImpl.waitUntilRunning()
        '''    
        start = time.time()
        end = 0
        node_list = ComputeContextImpl.waitUntilRunning(self, nodes, waitPeriodSeconds, timeoutSeconds)
        timeout = timeoutSeconds - (time.time() - start)
        if timeout > 0:
            end = time.time() + timeout
            while time.time() < end:
                ids = self._list_inaccessible_nodes(node_list)
                if ids:
                    time.sleep(waitPeriodSeconds)
                else:
                    return 
        raise Exception(value='Timed out after %s seconds' % (timeoutSeconds))
    
    def exWaitForPendingSpotNodes(self, waitPeriodSeconds=15, timeoutSeconds=600):
        if waitPeriodSeconds == None : waitPeriodSeconds = 15
        if timeoutSeconds == None: timeoutSeconds = 600
        self._ex_wait_for_pending_spot_nodes(waitPeriodSeconds, timeoutSeconds)
        
    def exListSecurityGroups(self):
        return wrap_listing(self.conn.ex_list_security_groups(),
                             str)
    
    def exCreateSecurityGroup(self, name, description="group"):
        self.conn.ex_create_security_group(name, description)
        
    def exDeleteSecurityGroup(self, name):
        return self.conn.ex_delete_security_group(name)
        
    def exAuthorizeSecurityGroup(self, name, from_port=22, to_port=22,
                                cidr_ip='0.0.0.0/0', protocol='tcp'):
        return self.conn.ex_authorize_security_group(name, from_port, to_port,
                                              cidr_ip, protocol)
        
    def exStartNode(self, node):
        return self.conn.ex_start_node(node.node)
    
    def exStopNode(self, node):
        return self.conn.ex_stop_node(node.node)
    
    def getTemplateBuilder(self): 
        return EC2NodeTemplateImpl.newBuilder()
    
    
    #--------------------------------------------#
    #Network specific methods                    #
    #--------------------------------------------#
    def exListNetworks(self):
        return wrap_listing(self.conn.ex_list_networks(), EC2NetworkImpl)
   
    def exCreateNetwork(self, cidr_block, name=None, instance_tenancy='default'):
        return EC2NetworkImpl(self.conn.ex_create_network(cidr_block, 
                                                          name, instance_tenancy))
   
    def exDeleteNetwork(self, network):
       return self.conn.ex_delete_network(network.ec2_network)
   
    def exListSubnets(self):
        return wrap_listing(self.conn.ex_list_subnets(), EC2NetworkSubnetImpl)
    
    def exCreateSubnet(self, vpc_id, cidr_block, availability_zone, name=None):
        return EC2NetworkSubnetImpl(self.conn.ex_create_subnet(vpc_id,
                                                               cidr_block, availability_zone, name))
    
    def exDeleteSubnet(self, subnet):
        return self.conn.ex_delete_subnet(subnet.ec2_network)
    
    #--------------------------------------------#
    # internal helper methods                    #
    #--------------------------------------------#
    def _parse_ec2_template(self, node_temp, kwargs):
        #check groups
        groups = node_temp.getGroups()
        if groups == None and self.prop != None:
            groups = [self.prop.getProperty('group_name')]
        if groups == None:
            group = self.conn.ex_list_security_groups()[0]
            if group != None:
                kwargs['ex_security_groups'] = group
            else:
                raise AttributeError("no groups available")
        else:
            tmp_groups = []
            for group in groups:
                tmp_groups.append(group)
            kwargs['ex_security_groups'] = tmp_groups 
        return kwargs
    
    def _recv_wait_set(self):
        params = {'Action': 'DescribeSpotInstanceRequests'}
        object = self.conn.connection.request(self.conn.path, params=params).object
        wait_ids = []
        for elem in object.findall(fixxpath(xpath='spotInstanceRequestSet/item', namespace=NAMESPACE)):
            inst_id = findtext(element=elem, xpath='spotInstanceRequestId',namespace=NAMESPACE)
            status = findtext(element=elem, xpath='status/code',namespace=NAMESPACE)
            if status == 'pending-evaluation' or status == 'pending-fulfillment':
                wait_ids.append(inst_id)
        return wait_ids
    
    def _ex_wait_for_pending_spot_nodes(self, wait_period, timeout):
        ''':keyword    spot_ids: A list SpotRequestIds
        :type       spot_ids:   ``list``
        pending-evaluation -> pending-fulfillment -> fulfilled
                        -> bad-parameters
        receives current spot instanceRequests. if a instance is in state pending-xxx
        the method blocks until no instance is in the state pending-xxx
        TODO: add name tag
        '''
        import time
        start = time.time()
        end = start + timeout
        
        while time.time() < end:
            if self._recv_wait_set():
                time.sleep(wait_period)
            else:
                return
            
        raise Exception(value='Timed out after %s seconds' % (timeout))
        
    def _list_inaccessible_nodes(self, node_list):
        '''returns node ids which aren't accessible via ssh yet'''
        params = {'Action' : 'DescribeInstanceStatus'}
        for index in range(len(node_list)):
            params['InstanceId.%d' % (index + 1,)] =\
                node_list[index].id
                    
        object = self.conn.connection.request(self.conn.path, params=params).object
        bad_ids = []
        for elem in object.findall(fixxpath(xpath='instanceStatusSet/item', namespace=NAMESPACE)):
                inst_id = findtext(element=elem, xpath='instanceId',namespace=NAMESPACE)
                sys_stat = findtext(element=elem, xpath='systemStatus/status',namespace=NAMESPACE)
                inst_stat = findtext(element=elem, xpath='instanceStatus/status',namespace=NAMESPACE)
                if sys_stat != 'ok' or inst_stat != 'ok':
                    bad_ids.append(inst_id)
        return bad_ids