from jlibcloud.driverSpecific.digitalocean import DigitalOceanComputeContext
from jlibcloud.driverSpecific.digitalocean import DigitalOceanNodeTemplateImpl

from javaimpl.ComputeContextImpl import ComputeContextImpl
from javaimpl.utils import wrap_listing
from javaimpl.utils import none_check

class DigitalOceanComputeContextImpl(ComputeContextImpl, DigitalOceanComputeContext):

	def __init__(self, builder):
		ComputeContextImpl.__init__(self, builder)

	def createNode(self, node_temp):
		kwargs = self._eval_template(node_temp)
		kwargs = self._parse_digitalocean_template(node_temp, kwargs)
		self.conn.create_node(**kwargs)

	def _parse_digitalocean_template(self, node_temp, kwargs):
		if node_temp.getExSshKeyIds():
			kwargs['ex_ssh_key_ids'] =  node_temp.getExSshKeyIds()
		return kwargs

	def exListSshKeys(self):
		'''
        List all the available SSH keys.

        :return: Available SSH keys.
        :rtype: ``list`` of :class:`SSHKey`
		'''
		return wrap_listing(self.conn.ex_list_ssh_keys(), SSHKeyImpl)

	def exCreateSshKey(self, name, ssh_key_pub):
		'''
        Create a new SSH key.

        :param      name: Key name (required)
        :type       name: ``str``

        :param      name: Valid public key string (required)
        :type       name: ``str``
		'''
		return self.conn.ex_create_ssh_key(name, ssh_key_pub)

	def exDestroySshKey(self, key_id):
		'''
        Delete an existing SSH key.

        :param      key_id: SSH key id (required)
        :type       key_id: ``str``
		'''
		return self.conn.ex_destroy_ssh_key(key_id)

	def getTemplateBuilder(self):
		return DigitalOceanNodeTemplateImpl.newBuilder()

from jlibcloud.driverSpecific.digitalocean import SSHKey as JSSHKey

class SSHKeyImpl(JSSHKey):

	def __init__(self, obj):
		self.conn = obj
		if hasattr(obj, 'id'):
			self.idp = none_check(obj.id, '')
		else:
			self.idp = ''
		if hasattr(obj, 'name'):
			self.namep = none_check(obj.name, '')
		else:
			self.namep = ''
		if hasattr(obj, 'pub_key'):
			self.pub_keyp = none_check(obj.pub_key, '')
		else:
			self.pub_keyp = ''
		if hasattr(obj, '__repr__()'):
			self.reprp = obj.__repr__()
		else:
			self.reprp = ''

	def getId(self):
		return self.idp

	def getName(self):
		return self.namep

	def getPubKey(self):
		return self.pub_keyp

	def toString(self):
		return self.reprp
