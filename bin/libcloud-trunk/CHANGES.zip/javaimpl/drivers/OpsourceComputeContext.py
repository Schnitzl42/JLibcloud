from jlibcloud.driverSpecific.opsource import OpsourceComputeContext
from jlibcloud.driverSpecific.opsource import OpsourceNodeTemplateImpl

from javaimpl.ComputeContextImpl import ComputeContextImpl
from javaimpl.utils import wrap_listing
from javaimpl.utils import none_check

class OpsourceComputeContextImpl(ComputeContextImpl, OpsourceComputeContext):

	def __init__(self, builder):
		ComputeContextImpl.__init__(self, builder)

	def createNode(self, node_temp):
		kwargs = self._eval_template(node_temp)
		kwargs = self._parse_opsource_template(node_temp, kwargs)
		self.conn.create_node(**kwargs)

	def _parse_opsource_template(self, node_temp, kwargs):
		if node_temp.getExNetwork():
			kwargs['ex_network'] =  node_temp.getExNetwork()
		if node_temp.getExIsStarted():
			kwargs['ex_isStarted'] =  node_temp.getExIsStarted()
		if node_temp.getExDescription():
			kwargs['ex_description'] =  node_temp.getExDescription()
		return kwargs

	def exStartNode(self, node):
		'''
        Powers on an existing deployed server

        :param      node: Node which should be used
        :type       node: :class:`Node`

        :rtype: ``bool``
		'''
		return self.conn.ex_start_node(node.node)

	def exShutdownGraceful(self, node):
		'''
        This function will attempt to "gracefully" stop a server by
        initiating a shutdown sequence within the guest operating system.
        A successful response on this function means the system has
        successfully passed the request into the operating system.

        :param      node: Node which should be used
        :type       node: :class:`Node`

        :rtype: ``bool``
		'''
		return self.conn.ex_shutdown_graceful(node.node)

	def exPowerOff(self, node):
		'''
        This function will abruptly power-off a server.  Unlike
        ex_shutdown_graceful, success ensures the node will stop but some OS
        and application configurations may be adversely affected by the
        equivalent of pulling the power plug out of the machine.

        :param      node: Node which should be used
        :type       node: :class:`Node`

        :rtype: ``bool``
		'''
		return self.conn.ex_power_off(node.node)

	def exListNetworks(self):
		'''
        List networks deployed across all data center locations for your
        organization.  The response includes the location of each network.

        :return: a list of OpsourceNetwork objects
        :rtype: ``list`` of :class:`OpsourceNetwork`
		'''
		return wrap_listing(self.conn.ex_list_networks(), OpsourceNetworkImpl)

	def exGetLocationById(self, id):
		'''
        Get location by ID.

        :param  id: ID of the node location which should be used
        :type   id: ``str``

        :rtype: :class:`NodeLocation`
		'''
		from javaimpl.base.NodeLocationImpl import NodeLocationImpl
		return NodeLocationImpl(self.conn.ex_get_location_by_id(id))

	def getTemplateBuilder(self):
		return OpsourceNodeTemplateImpl.newBuilder()

from jlibcloud.driverSpecific.opsource import OpsourceStatus as JOpsourceStatus

class OpsourceStatusImpl(JOpsourceStatus):

	def __init__(self, obj):
		self.obj = obj
		if hasattr(obj, 'step_percentComplete'):
			self.step_percentCompletep = none_check(obj.step_percentComplete, '')
		else:
			self.step_percentCompletep = ''
		if hasattr(obj, 'requestTime'):
			self.requestTimep = none_check(obj.requestTime, '')
		else:
			self.requestTimep = ''
		if hasattr(obj, 'updateTime'):
			self.updateTimep = none_check(obj.updateTime, '')
		else:
			self.updateTimep = ''
		if hasattr(obj, 'action'):
			self.actionp = none_check(obj.action, '')
		else:
			self.actionp = ''
		if hasattr(obj, 'failureReason'):
			self.failureReasonp = none_check(obj.failureReason, '')
		else:
			self.failureReasonp = ''
		if hasattr(obj, 'userName'):
			self.userNamep = none_check(obj.userName, '')
		else:
			self.userNamep = ''
		if hasattr(obj, 'step_name'):
			self.step_namep = none_check(obj.step_name, '')
		else:
			self.step_namep = ''
		if hasattr(obj, 'numberOfSteps'):
			self.numberOfStepsp = none_check(obj.numberOfSteps, '')
		else:
			self.numberOfStepsp = ''
		if hasattr(obj, 'step_number'):
			self.step_numberp = obj.step_number
		else:
			self.step_numberp = None
		if hasattr(obj, '__repr__()'):
			self.reprp = obj.__repr__()
		else:
			self.reprp = ''

	def getStepPercentComplete(self):
		return self.step_percentCompletep

	def getRequestTime(self):
		return self.requestTimep

	def getUpdateTime(self):
		return self.updateTimep

	def getAction(self):
		return self.actionp

	def getFailureReason(self):
		return self.failureReasonp

	def getUserName(self):
		return self.userNamep

	def getStepName(self):
		return self.step_namep

	def getNumberOfSteps(self):
		return self.numberOfStepsp

	def getStepNumber(self):
		return self.step_numberp

	def toString(self):
		return self.reprp

from jlibcloud.driverSpecific.opsource import OpsourceNetwork as JOpsourceNetwork

class OpsourceNetworkImpl(JOpsourceNetwork):

	def __init__(self, obj):
		self.conn = obj
		if hasattr(obj, 'id'):
			self.idp = none_check(obj.id, '')
		else:
			self.idp = ''
		if hasattr(obj, 'status'):
			self.statusp = none_check(obj.status, '')
		else:
			self.statusp = ''
		if hasattr(obj, 'location'):
			self.locationp = none_check(obj.location, '')
		else:
			self.locationp = ''
		if hasattr(obj, 'privateNet'):
			self.privateNetp = none_check(obj.privateNet, '')
		else:
			self.privateNetp = ''
		if hasattr(obj, 'description'):
			self.descriptionp = none_check(obj.description, '')
		else:
			self.descriptionp = ''
		if hasattr(obj, 'name'):
			self.namep = none_check(obj.name, '')
		else:
			self.namep = ''
		if hasattr(obj, 'multicast'):
			self.multicastp = none_check(obj.multicast, '')
		else:
			self.multicastp = ''
		if hasattr(obj, '__repr__()'):
			self.reprp = obj.__repr__()
		else:
			self.reprp = ''

	def getId(self):
		return self.idp

	def getStatus(self):
		return self.statusp

	def getLocation(self):
		return self.locationp

	def getPrivateNet(self):
		return self.privateNetp

	def getDescription(self):
		return self.descriptionp

	def getName(self):
		return self.namep

	def getMulticast(self):
		return self.multicastp

	def toString(self):
		return self.reprp
