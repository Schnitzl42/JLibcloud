from jlibcloud.driverSpecific.gogrid import GoGridComputeContext
from jlibcloud.driverSpecific.gogrid import GoGridNodeTemplateImpl

from javaimpl.ComputeContextImpl import ComputeContextImpl
from javaimpl.utils import wrap_listing
from javaimpl.utils import none_check

class GoGridComputeContextImpl(ComputeContextImpl, GoGridComputeContext):

	def __init__(self, builder):
		ComputeContextImpl.__init__(self, builder)

	def exCreateNodeNowait(self, **kwargs):
		'''
        but return right away with id == None.

        The existance of this method is explained by the fact
        that GoGrid assigns id to a node only few minutes after
        creation.


        :keyword    name:   String with a name for this new node (required)
        :type       name:   ``str``

        :keyword    size:   The size of resources allocated to this node .
                            (required)
        :type       size:   :class:`NodeSize`

        :keyword    image:  OS Image to boot on node. (required)
        :type       image:  :class:`NodeImage`

        :keyword    ex_description: Description of a Node
        :type       ex_description: ``str``

        :keyword    ex_ip: Public IP address to use for a Node. If not
            specified, first available IP address will be picked
        :type       ex_ip: ``str``

        :rtype: :class:`GoGridNode`
		'''
		return GoGridNodeImpl(self.conn.ex_create_node_nowait(**kwargs))

	def createNode(self, node_temp):
		kwargs = self._eval_template(node_temp)
		kwargs = self._parse_gogrid_template(node_temp, kwargs)
		self.conn.create_node(**kwargs)

	def _parse_gogrid_template(self, node_temp, kwargs):
		if node_temp.getExIp():
			kwargs['ex_ip'] =  node_temp.getExIp()
		if node_temp.getExDescription():
			kwargs['ex_description'] =  node_temp.getExDescription()
		return kwargs

	def exSaveImage(self, node, name):
		'''

        Please refer to GoGrid documentation to get info
        how prepare a node for image creation:

        http://wiki.gogrid.com/wiki/index.php/MyGSI

        :keyword    node: node to use as a base for image
        :type       node: :class:`GoGridNode`

        :keyword    name: name for new image
        :type       name: ``str``

        :rtype: :class:`NodeImage`
		'''
		return NodeImageImpl(self.conn.ex_save_image(node.node, name))

	def exEditNode(self, kwargs):
		'''

        :keyword    node: node to be edited (required)
        :type       node: :class:`GoGridNode`

        :keyword    size: new size of a node (required)
        :type       size: :class:`NodeSize`

        :keyword    ex_description: new description of a node
        :type       ex_description: ``str``

        :rtype: :class:`Node`
		'''
		from javaimpl.base.NodeImpl import NodeImpl
		return NodeImpl(self.conn.ex_edit_node(**kwargs))

	def exEditImage(self, kwargs):
		'''

        :keyword    image: image to be edited (required)
        :type       image: :class:`NodeImage`

        :keyword    public: should be the image public (required)
        :type       public: ``bool``

        :keyword    ex_description: description of the image (optional)
        :type       ex_description: ``str``

        :keyword    name: name of the image
        :type       name ``str``

        :rtype: :class:`NodeImage`
		'''
		return NodeImageImpl(self.conn.ex_edit_image(**kwargs))

	def exListIps(self, kwargs):
		'''
        the account.

        :keyword    public: set to True to list only
                    public IPs or False to list only
                    private IPs. Set to None or not specify
                    at all not to filter by type
        :type       public: ``bool``

        :keyword    assigned: set to True to list only addresses
                    assigned to servers, False to list unassigned
                    addresses and set to None or don't set at all
                    not no filter by state
        :type       assigned: ``bool``

        :keyword    location: filter IP addresses by location
        :type       location: :class:`NodeLocation`

        :rtype: ``list`` of :class:`GoGridIpAddress`
		'''
		return wrap_listing(self.conn.ex_list_ips(**kwargs), GoGridIpAddressImpl)

	def getTemplateBuilder(self):
		return GoGridNodeTemplateImpl.newBuilder()

from jlibcloud.driverSpecific.gogrid import GoGridNode as JGoGridNode
from javaimpl.base.NodeImpl import NodeImpl

class GoGridNodeImpl(JGoGridNode, NodeImpl):

	def __init__(self, obj):
		NodeImpl.__init__(self, obj)
		
	def getUuid(self):
		return self.obj.get_uuid()
	
from jlibcloud.driverSpecific.gogrid import GoGridIpAdress as JGoGridIpAdress

class GoGridIpAddressImpl(JGoGridIpAdress):
	
	def __init__(self, obj):
		self.obj = obj
		if hasattr(obj, 'id'):
			self.idp = none_check(obj.id, '')
		else:
			self.idp = ''
		if hasattr(obj, 'ip'):
			self.ipp = none_check(obj.ip, '')
		else:
			self.ipp = ''
		if hasattr(obj, 'public'):
			self.publicp = none_check(obj.public, '')
		else:
			self.publicp = ''
		if hasattr(obj, 'state'):
			self.statep = none_check(obj.state, '')
		else:
			self.statep = ''
		if hasattr(obj, 'subnet'):
			self.subnetp = none_check(obj.subnet, '')
		else:
			self.subnetp = ''
			
	def getId(self):
		return self.idp
	
	def getIp(self):
		return self.ipp
	
	def getPublic(self):
		return self.publicp
	
	def getState(self):
		return self.statep
	
	def getSubnet(self):
		return self.subnetp
