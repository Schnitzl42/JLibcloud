from jlibcloud.driverSpecific.abiquo import AbiquoComputeContext
from jlibcloud.driverSpecific.abiquo import AbiquoNodeTemplateImpl

from javaimpl.ComputeContextImpl import ComputeContextImpl
from javaimpl.utils import wrap_listing
from javaimpl.utils import none_check
from javaimpl.base import NodeImpl

class AbiquoComputeContextImpl(ComputeContextImpl, AbiquoComputeContext):

	def __init__(self, builder):
		ComputeContextImpl.__init__(self, builder)

	def createNode(self, node_temp):
		kwargs = self._eval_template(node_temp)
		kwargs = self._parse_abiquo_template(node_temp, kwargs)
		self.conn.create_node(**kwargs)

	def _parse_abiquo_template(self, node_temp, kwargs):
		if node_temp.getGroupName():
			kwargs['group_name'] =  node_temp.getGroupName()
		return kwargs

	def exRunNode(self, node):
		'''
        Runs a node

        Here there is a bit difference between Abiquo states and libcloud
        states, so this method is created to have better compatibility. In
        libcloud, if the node is not running, then it does not exist (avoiding
        UNKNOWN and temporal states). In Abiquo, you can define a node, and
        then deploy it.

        If the node is in :class:`NodeState.TERMINATED` libcloud's state and in
        'NOT_DEPLOYED' Abiquo state, there is a way to run and recover it
        for libcloud using this method. There is no way to reach this state
        if you are using only libcloud, but you may have used another Abiquo
        client and now you want to recover your node to be used by libcloud.

        :param node: The node to run
        :type node: :class:`Node`

        :return: The node itself, but with the new state
        :rtype: :class:`Node`
		'''
		return NodeImpl(self.conn.ex_run_node(node.node))

	def exPopulateCache(self):
		'''
        Populate the cache.

        For each connection, it is good to store some objects that will be
        useful for further requests, such as the 'user' and the 'enterprise'
        objects.

        Executes the 'login' resource after setting the connection parameters
        and, if the execution is successful, it sets the 'user' object into
        cache. After that, it also requests for the 'enterprise' and
        'locations' data.

        List of locations should remain the same for a single libcloud
        connection. However, this method is public and you are able to
        refresh the list of locations any time.
		'''
		self.conn.ex_populate_cache()

	def exCreateGroup(self, name, location=None):
		'''
        Create an empty group.

        You can specify the location as well.

        :param     name:     name of the group (required)
        :type      name:     ``str``

        :param     location: location were to create the group
        :type      location: :class:`NodeLocation`

        :returns:            the created group
        :rtype:              :class:`NodeGroup`
		'''
		if location:
			return NodeGroupImpl(self.conn.ex_create_group(name, location.location))
		else:
			return NodeGroupImpl(self.conn.ex_create_group(name))

	def exDestroyGroup(self, group):
		'''
        Destroy a group.

        Be careful! Destroying a group means destroying all the :class:`Node`s
        there and the group itself!

        If there is currently any action over any :class:`Node` of the
        :class:`NodeGroup`, then the method will raise an exception.

        :param     name: The group (required)
        :type      name: :class:`NodeGroup`

        :return:         If the group was destroyed successfully
        :rtype:          ``bool``
		'''
		return self.conn.ex_destroy_group(group.group)

	def exListGroups(self, location=None):
		'''
        List all groups.

        :param location: filter the groups by location (optional)
        :type  location: a :class:`NodeLocation` instance.

        :return:         the list of :class:`NodeGroup`
		'''
		if location:
			return wrap_listing(self.conn.ex_list_groups(location), NodeGroupImpl)
		else:
			return wrap_listing(self.conn.ex_list_groups(), NodeGroupImpl)

	def getTemplateBuilder(self):
		return AbiquoNodeTemplateImpl.newBuilder()

from jlibcloud.driverSpecific.abiquo import NodeGroup as JNodeGroup

class NodeGroupImpl(JNodeGroup):

	def __init__(self, obj):
		self.group = obj
		from libcloud.compute.drivers.abiquo import NodeGroup
		if isinstance(obj, NodeGroup):
			self.nodesp = obj.nodes
			self.namep = none_check(obj.name, '')
			self.urip = none_check(obj.uri, '')
			self.reprp = obj.__repr__()
		else:
			self.nodesp = []
			self.namep = ''
			self.urip = ''
			self.reprp = ''

	def getNodes(self):
		return wrap_listing(self.nodesp, NodeImpl)

	def getName(self):
		return self.namep

	def getUri(self):
		return self.urip

	def toString(self):
		return self.reprp

	def destroy(self):
		'''
        Destroys the group delegating the execution to
        :class:`AbiquoNodeDriver`.
		'''
		return self.group.destroy()

