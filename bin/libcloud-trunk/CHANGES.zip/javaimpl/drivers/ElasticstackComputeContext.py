from jlibcloud.driverSpecific.elasticstack import ElasticStackBaseComputeContext
from jlibcloud.driverSpecific.elasticstack import ElasticStackBaseNodeTemplateImpl

from javaimpl.ComputeContextImpl import ComputeContextImpl
from javaimpl.utils import wrap_listing
from javaimpl.utils import none_check

class ElasticStackBaseComputeContextImpl(ComputeContextImpl, ElasticStackBaseComputeContext):

	def __init__(self, builder):
		ComputeContextImpl.__init__(self, builder)

	def createNode(self, node_temp):
		kwargs = self._eval_template(node_temp)
		kwargs = self._parse_elasticstackbase_template(node_temp, kwargs)
		self.conn.create_node(**kwargs)

	def _parse_elasticstackbase_template(self, node_temp, kwargs):
		if node_temp.getSmp():
			kwargs['smp'] =  node_temp.getSmp()
		if node_temp.getVncPassword():
			kwargs['vnc_password'] =  node_temp.getVncPassword()
		if node_temp.getNicModel():
			kwargs['nic_model'] =  node_temp.getNicModel()
		return kwargs

	def exSetNodeConfiguration(self, node, kwargs):
		'''
        Changes the configuration of the running server

        :param      node: Node which should be used
        :type       node: :class:`Node`

        :param      kwargs: keyword arguments
        :type       kwargs: ``dict``

        :rtype: ``bool``
		'''
		return self.conn.ex_set_node_configuration(node.node, **kwargs)

	def exShutdownNode(self, node):
		'''
        Sends the ACPI power-down event

        :param      node: Node which should be used
        :type       node: :class:`Node`

        :rtype: ``bool``
		'''
		return self.conn.ex_shutdown_node(node.node)

	def exDestroyDrive(self, drive_uuid):
		'''
        Deletes a drive

        :param      drive_uuid: Drive uuid which should be used
        :type       drive_uuid: ``str``

        :rtype: ``bool``
		'''
		return self.conn.ex_destroy_drive(drive_uuid)

	def getTemplateBuilder(self):
		return ElasticStackBaseNodeTemplateImpl.newBuilder()

from jlibcloud.driverSpecific.elasticstack import ElasticStackNodeSize as JElasticStackNodeSize
from javaimpl.base.NodeSizeImpl import NodeSizeImpl 

class ElasticStackNodeSizeImpl(JElasticStackNodeSize, NodeSizeImpl):

	def __init__(self, obj):
		NodeSizeImpl.__init__(self, obj)
		self.size = obj
		if hasattr(obj, 'id'):
			self.idp = none_check(obj.id, '')
		else:
			self.idp = ''
		if hasattr(obj, 'price'):
			self.pricep = none_check(obj.price, -1.0)
		else:
			self.pricep = -1.0
		if hasattr(obj, 'ram'):
			self.ramp = none_check(obj.ram, -1)
		else:
			self.ramp = -1
		if hasattr(obj, 'disk'):
			self.diskp = none_check(obj.disk, -1)
		else:
			self.diskp = -1
		if hasattr(obj, 'name'):
			self.namep = none_check(obj.name, '')
		else:
			self.namep = ''
		if hasattr(obj, 'cpu'):
			self.cpup = none_check(obj.cpu, '')
		else:
			self.cpup = ''
		if hasattr(obj, 'bandwidth'):
			self.bandwidthp = none_check(obj.bandwidth, -1)
		else:
			self.bandwidthp = -1
		if hasattr(obj, '__repr__()'):
			self.reprp = obj.__repr__()
		else:
			self.reprp = ''

	def getId(self):
		return self.idp

	def getPrice(self):
		return self.pricep

	def getRam(self):
		return self.ramp

	def getDisk(self):
		return self.diskp

	def getName(self):
		return self.namep

	def getCpu(self):
		return self.cpup

	def getBandwidth(self):
		return self.bandwidthp

	def toString(self):
		return self.reprp
