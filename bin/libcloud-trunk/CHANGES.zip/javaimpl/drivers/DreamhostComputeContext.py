from jlibcloud.driverSpecific.dreamhost import DreamhostComputeContext
from jlibcloud.driverSpecific.dreamhost import DreamhostNodeTemplateImpl

from javaimpl.ComputeContextImpl import ComputeContextImpl
from javaimpl.utils import wrap_listing
from javaimpl.utils import none_check

class DreamhostComputeContextImpl(ComputeContextImpl, DreamhostComputeContext):

	def __init__(self, builder):
		ComputeContextImpl.__init__(self, builder)

	def createNode(self, node_temp):
		kwargs = self._eval_template(node_temp)
		kwargs = self._parse_dreamhost_template(node_temp, kwargs)
		self.conn.create_node(**kwargs)

	def _parse_dreamhost_template(self, node_temp, kwargs):
		if node_temp.getExMovedata():
			kwargs['ex_movedata'] =  node_temp.getExMovedata()
		return kwargs

	def getTemplateBuilder(self):
		return DreamhostNodeTemplateImpl.newBuilder()

