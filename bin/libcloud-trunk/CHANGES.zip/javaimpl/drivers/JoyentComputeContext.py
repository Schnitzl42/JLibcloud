from jlibcloud.driverSpecific.joyent import JoyentComputeContext
from jlibcloud.driverSpecific.joyent import JoyentNodeTemplateImpl

from javaimpl.ComputeContextImpl import ComputeContextImpl
from javaimpl.utils import wrap_listing
from javaimpl.utils import none_check

class JoyentComputeContextImpl(ComputeContextImpl, JoyentComputeContext):

	def __init__(self, builder):
		ComputeContextImpl.__init__(self, builder)

	def exStopNode(self, node):
		'''
        Stop node

        :param  node: The node to be stopped
        :type   node: :class:`Node`

        :rtype: ``bool``
		'''
		return self.conn.ex_stop_node(node.node)

	def exStartNode(self, node):
		'''
        Start node

        :param  node: The node to be stopped
        :type   node: :class:`Node`

        :rtype: ``bool``
		'''
		return self.conn.ex_start_node(node.node)

