from jlibcloud.driverSpecific.gandi import GandiComputeContext
from jlibcloud.driverSpecific.gandi import GandiNodeTemplateImpl

from javaimpl.ComputeContextImpl import ComputeContextImpl
from javaimpl.utils import wrap_listing
from javaimpl.utils import none_check

class GandiComputeContextImpl(ComputeContextImpl, GandiComputeContext):

	def __init__(self, builder):
		ComputeContextImpl.__init__(self, builder)

	def createNode(self, node_temp):
		kwargs = self._eval_template(node_temp)
		kwargs = self._parse_gandi_template(node_temp, kwargs)
		self.conn.create_node(**kwargs)

	def _parse_gandi_template(self, node_temp, kwargs):
		if node_temp.getInetFamily():
			kwargs['inet_family'] =  node_temp.getInetFamily()
		if node_temp.getLogin():
			kwargs['login'] =  node_temp.getLogin()
		if node_temp.getPassword():
			kwargs['password'] =  node_temp.getPassword()
		return kwargs

	def exListInterfaces(self):
		'''
        Specific method to list network interfaces

        :rtype: ``list`` of :class:`GandiNetworkInterface`
		'''
		return wrap_listing(self.conn.ex_list_interfaces(), NetworkInterfaceImpl)

	def exListDisks(self):
		'''
        Specific method to list all disk

        :rtype: ``list`` of :class:`GandiDisk`
		'''
		return wrap_listing(self.conn.ex_list_disks(), DiskImpl)

	def exNodeAttachDisk(self, node, disk):
		'''
        Specific method to attach a disk to a node

        :param      node: Node which should be used
        :type       node: :class:`Node`

        :param      disk: Disk which should be used
        :type       disk: :class:`GandiDisk`

        :rtype: ``bool``
		'''
		return self.conn.ex_node_attach_disk(node.node, disk.disk)

	def exNodeDetachDisk(self, node, disk):
		'''
        Specific method to detach a disk from a node

        :param      node: Node which should be used
        :type       node: :class:`Node`

        :param      disk: Disk which should be used
        :type       disk: :class:`GandiDisk`

        :rtype: ``bool``
		'''
		return self.conn.ex_node_detach_disk(node.node, disk.disk)

	def exNodeAttachInterface(self, node, iface):
		'''
        Specific method to attach an interface to a node

        :param      node: Node which should be used
        :type       node: :class:`Node`


        :param      iface: Network interface which should be used
        :type       iface: :class:`GandiNetworkInterface`

        :rtype: ``bool``
		'''
		return self.conn.ex_node_attach_interface(node.node, iface.obj)

	def exNodeDetachInterface(self, node, iface):
		'''
        Specific method to detach an interface from a node

        :param      node: Node which should be used
        :type       node: :class:`Node`


        :param      iface: Network interface which should be used
        :type       iface: :class:`GandiNetworkInterface`

        :rtype: ``bool``
		'''
		return self.conn.ex_node_detach_interface(node.node, iface.obj)

	def exSnapshotDisk(self, disk, name=None):
		'''
        Specific method to make a snapshot of a disk

        :param      disk: Disk which should be used
        :type       disk: :class:`GandiDisk`

        :param      name: Name which should be used
        :type       name: ``str``

        :rtype: ``bool``
		'''
		if name:
			return self.conn.ex_snapshot_disk(disk, name)
		else:
			return self.conn.ex_snapshot_disk(disk, name)

	def exUpdateDisk(self, disk, new_size=None, new_name=None):
		'''
        WARNING: if a server is attached it'll be rebooted

        :param      disk: Disk which should be used
        :type       disk: :class:`GandiDisk`

        :param      new_size: New size
        :type       new_size: ``int``

        :param      new_name: New name
        :type       new_name: ``str``

        :rtype: ``bool``
		'''
		return self.conn.ex_update_disk(disk, new_size, new_name)

	def getTemplateBuilder(self):
		return GandiNodeTemplateImpl.newBuilder()

from jlibcloud.driverSpecific.gandi import NetworkInterface as JNetworkInterface

class NetworkInterfaceImpl(JNetworkInterface):

	def __init__(self, obj):
		self.obj = obj
		if hasattr(obj, 'mac_address'):
			self.mac_addressp = none_check(obj.mac_address, '')
		else:
			self.mac_addressp = ''
		if hasattr(obj, 'node_id'):
			self.node_idp = none_check(obj.node_id, '')
		else:
			self.node_idp = ''
		if hasatttr(obj, 'ips'):
			self.ipsp = obj.ips
		else:
			self.ipsp = {}
		if hasatttr(obj, 'extra'):
			self.extrap = obj.extra
		else:
			self.extrap = {}
		if hasattr(obj, '__repr__()'):
			self.reprp = obj.__repr__()
		else:
			self.reprp = ''

	def getMac_address(self):
		return self.mac_addressp

	def getNode_id(self):
		return self.node_idp
	
	def getIps(self):
		return self.ipsp
	
	def getExtra(self):
		return self.extrap
	
	def toString(self):
		return self.reprp

from jlibcloud.driverSpecific.gandi import Disk as JDisk

class DiskImpl(JDisk):

	def __init__(self, obj):
		self.disk = obj
		if hasattr(obj, 'name'):
			self.namep = none_check(obj.name, '')
		else:
			self.namep = ''
		if hasattr(obj, 'size'):
			self.sizep = none_check(obj.size, '')
		else:
			self.sizep = ''
		if hasatttr(obj, 'extra'):
			self.extrap = obj.extra
		else:
			self.extrap = {}
		if hasattr(obj, '__repr__()'):
			self.reprp = obj.__repr__()
		else:
			self.reprp = ''

	def getName(self):
		return self.namep

	def getSize(self):
		return self.sizep
	
	def getExtra(self):
		return self.extrap
	
	def toString(self):
		return self.reprp

