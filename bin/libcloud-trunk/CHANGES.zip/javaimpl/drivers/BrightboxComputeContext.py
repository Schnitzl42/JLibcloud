from jlibcloud.driverSpecific.brightbox import BrightboxComputeContext
from jlibcloud.driverSpecific.brightbox import BrightboxNodeTemplateImpl

from javaimpl.ComputeContextImpl import ComputeContextImpl
from javaimpl.utils import wrap_listing
from javaimpl.utils import none_check

class BrightboxComputeContextImpl(ComputeContextImpl, BrightboxComputeContext):

	def __init__(self, builder):
		ComputeContextImpl.__init__(self, builder)

	def createNode(self, node_temp):
		kwargs = self._eval_template(node_temp)
		kwargs = self._parse_brightbox_template(node_temp, kwargs)
		self.conn.create_node(**kwargs)

	def _parse_brightbox_template(self, node_temp, kwargs):
		if node_temp.getExServergroup():
			kwargs['ex_servergroup'] =  node_temp.getExServergroup()
		if node_temp.getExUserdata():
			kwargs['ex_userdata'] =  node_temp.getExUserdata()
		return kwargs

	def exListCloudIps(self):
		'''
        List Cloud IPs

        @note: This is an API extension for use on Brightbox

        :rtype: ``list`` of ``dict``
		'''
		return self.conn.ex_list_cloud_ips()

	def exCreateCloudIp(self, reverse_dns):
		'''
        Requests a new cloud IP address for the account

        @note: This is an API extension for use on Brightbox

        :param      reverse_dns: Reverse DNS hostname
        :type       reverse_dns: ``str``

        :rtype: ``dict``
		'''
		return self.conn.ex_create_cloud_ip(reverse_dns)

	def exUpdateCloudIp(self, cloud_ip_id, reverse_dns):
		'''
        Update some details of the cloud IP address

        @note: This is an API extension for use on Brightbox

        :param  cloud_ip_id: The id of the cloud ip.
        :type   cloud_ip_id: ``str``

        :param      reverse_dns: Reverse DNS hostname
        :type       reverse_dns: ``str``

        :rtype: ``dict``
		'''
		return self.conn.ex_update_cloud_ip(cloud_ip_id, reverse_dns)

	def exMapCloudIp(self, cloud_ip_id, interface_id):
		'''
        Maps (or points) a cloud IP address at a server's interface
        or a load balancer to allow them to respond to public requests

        @note: This is an API extension for use on Brightbox

        :param  cloud_ip_id: The id of the cloud ip.
        :type   cloud_ip_id: ``str``

        :param  interface_id: The Interface ID or LoadBalancer ID to
                              which this Cloud IP should be mapped to
        :type   interface_id: ``str``

        :return: True if the mapping was successful.
        :rtype: ``bool``
		'''
		return self.conn.ex_map_cloud_ip(cloud_ip_id, interface_id)

	def exUnmapCloudIp(self, cloud_ip_id):
		'''
        Unmaps a cloud IP address from its current destination making
        it available to remap. This remains in the account's pool
        of addresses

        @note: This is an API extension for use on Brightbox

        :param  cloud_ip_id: The id of the cloud ip.
        :type   cloud_ip_id: ``str``

        :return: True if the unmap was successful.
        :rtype: ``bool``
		'''
		return self.conn.ex_unmap_cloud_ip(cloud_ip_id)

	def exDestroyCloudIp(self, cloud_ip_id):
		'''
        Release the cloud IP address from the account's ownership

        @note: This is an API extension for use on Brightbox

        :param  cloud_ip_id: The id of the cloud ip.
        :type   cloud_ip_id: ``str``

        :return: True if the unmap was successful.
        :rtype: ``bool``
		'''
		return self.conn.ex_destroy_cloud_ip(cloud_ip_id)

	def getTemplateBuilder(self):
		return BrightboxNodeTemplateImpl.newBuilder()

