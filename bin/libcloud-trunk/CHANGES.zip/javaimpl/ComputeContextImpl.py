'''
Created on 11.12.2013

@author: root
'''
from jlibcloud.wrapperInterfaces import ComputeContext
from jlibcloud.wrapperInterfacesImpl import NodeTemplateImpl

from libcloud.compute.types import Provider, NodeState
from libcloud.compute.providers import get_driver
from libcloud.compute.base import NodeAuthSSHKey
from libcloud.compute.base import NodeImage, NodeSize

from utils import wrap_listing
from utils import none_check
from base.KeyPairImpl import KeyPairImpl
from base.VolumeSnapshotImpl import VolumeSnapshotImpl
from base.NodeImpl import NodeImpl
from base.NodeImageImpl import NodeImageImpl
from base.NodeSizeImpl import NodeSizeImpl
from base.NodeLocationImpl import NodeLocationImpl
from base.VolumeSnapshotImpl import VolumeSnapshotImpl
from base.StorageVolumeImpl import StorageVolumeImpl

class ComputeContextImpl(ComputeContext):
    def __init__(self, builder):
        self.provider = builder.getProvider()
        self.driver = get_driver(self.provider)
        self.prop = builder.getProperties()

        args = ()
        kwargs = {}
        #load credentials from file
        if builder.getFilePath():
            argss = self._load_creds(builder.getFilePath())
            args = argss[0]
            kwargs = argss[1]
        else:
            #key, secret=None, secure=True, host=None, port=None, api_version=None
            key = builder.getIdentity()
            secret = builder.getAuthentication()
            host = builder.getHost()
            port = builder.getPort()
            secure = builder.isSecure()
            api_version = builder.getApiVersion()
            if self.provider=='abiquo':
                args = (key, secret.encode('ascii', 'ignore'),
                        builder.getEndpoint())
            
            #if (id, auth, host, port, secure, apiVersion) was called    
            elif api_version:
                args = (key, secret.encode('ascii', 'ignore'),
                        secure, host, port, api_version)
            #if (id, auth, host, port) was called
            elif host:
                args = (key, secret.encode('ascii', 'ignore'),
                        secure, host, port)
             #if it was called with identity, authentification
            elif secret:
                args = (key, secret.encode('ascii', 'ignore'))
            #if no secret is required
            else:
                args = (key)
        #special kwargs arguments
        if builder.getRegion():
            kwargs['region'] = builder.getRegion()
        self.conn = self.driver(*args, **kwargs)
        # caching variables
        self.size_cache = None
    
    
    #--------------------------------------------#
    # methods which directly operate on nodes    #
    #--------------------------------------------#
    def createNode(self, node_temp):
        kwargs = self._eval_template(node_temp)
        self.conn.create_node(**kwargs)
        
    def destroyNode(self, node):
        return node.destroy()
    
    def rebootNode(self, node):
        return node.reboot()
    
    def waitUntilRunning(self, nodes, waitPeriodSeconds=5, timeoutSeconds=600):
        node_list = []
        for node in nodes:
            if node.getState() == NodeState.PENDING or node.getState() == NodeState.REBOOTING:
                node_list.append(node.node)
                
        try:
            self.conn.wait_until_running(node_list, wait_period=waitPeriodSeconds, timeout=timeoutSeconds)
            #return node list for overwritting drivers
            return node_list
        except Exception:
             raise Exception(value='Timed out after %s seconds' % (timeoutSeconds))
   
    
    #--------------------------------------------#
    # methods for listing information            #
    #--------------------------------------------#
    def listNodes(self):
        return wrap_listing(self.conn.list_nodes(), NodeImpl)
        
    def listImages(self, location=None):
        if location:
            return wrap_listing(self.conn.list_images(location.location), NodeImageImpl)
        else:
            return wrap_listing(self.conn.list_images(), NodeImageImpl)
    
    def listSizes(self):
        return wrap_listing(self._list_sizes_cached(), NodeSizeImpl)
    
    def listLocations(self):
        return wrap_listing(self.conn.list_locations(), NodeLocationImpl)
    
    def listVolumes(self):
        return wrap_listing(self.conn.list_volumes(), StorageVolumeImpl)
    
    def listVolumeSnapshots(self, volume):
        return wrap_listing(self.conn.list_volume_snapshots(volume.volume), VolumeSnapshotImpl)
    
    def listKeyPairs(self):
        return wrap_listing(self.conn.list_key_pairs(), KeyPairImpl)
    
    def getNodeStateMap(self):
        return self.driver.NODE_STATE_MAP
    
    #--------------------------------------------#
    # Volume specific methods                    #
    #--------------------------------------------#
    def createVolume(self, size, name, location=None, snapshot=None):
        return self.conn.create_volume(size, name, location.location, snapshot.snapshot)
    
    def attachVolume(self, node, volume, device=None):
        return self.conn.attach_volume(node.node, volume.volume, device)
    
    def detachVolume(self, volume):
        return self.conn.detach_volume(volume.volume)
    
    def destroyVolume(self, volume):
        return self.conn.destroy_volume(volume.volume)
    
    def createVolumeSnapshot(self, volume, name):
        return VolumeSnapshotImpl(self.conn.create_volume_snapshot(volume.volume, name))
    
    def destroyVolumeSnapshot(self, snapshot):
        return self.conn.destroy_volume_snapshot(snapshot.snapshot)
    
    #--------------------------------------------#
    #SSH key pair specific methods (should be in official 0.14 release)
    #--------------------------------------------#
    def getKeyPair(self, name):
        return KeyPairImpl(self.conn.get_key_pair(name))
    
    def createKeyPair(self, name):
        return KeyPairImpl(self.conn.create_key_pair(name))
               
    def importKeyPairFromString(self, name, key_material):
        return KeyPairImpl(self.conn.import_key_pair_from_string(name, key_material))
        
    def importKeyPairFromFile(self, name, key_path):
        return KeyPairImpl(self.conn.import_key_pair_from_file(name, key_path))
    
    def deleteKeyPair(self, key_pair):
        self.conn.delete_key_pair(key_pair.key_pair)
        
    #--------------------------------------------#
    # non libcloud methods                       #
    #--------------------------------------------#
    def getTemplateBuilder(self): 
        return NodeTemplateImpl.newBuilder();
    
    def getProviderName(self):
        return self.provider
    
    #--------------------------------------------#
    # internal helper methods                    #
    #--------------------------------------------#
    def _eval_template(self, node_temp):
        #TODO: keypair support?
        kwargs = {}
        size_id = node_temp.getSizeId()
        image_id = node_temp.getImageId()
        name = node_temp.getNodeName()
        #check if None attributes can be loaded from self.prop
        if size_id == None and self.prop != None:
            size_id = self.prop.getProperty('size_id')
        if image_id == None and self.prop != None:
            image_id = self.prop.getProperty('image_id')
        if name == None and self.prop != None:
            name = self.prop.getProperty('name')
        #if size or image are still None throw an Exception    
        if size_id == None or image_id == None:
            raise AttributeError('sizeId or imageId not set!')
            #kwargs['size'] = self._list_sizes_cached()[0]
            #kwargs['images'] = self._list_images_cached()[0] 
        #assign values
        #TODO: replace calls with ids objects with only ids
        #TODO: replace size call to local object with id
        #since hopefully every provider only uses the id
        #self, id, name, ram, disk, bandwidth, price,
                 #driver, extra=None
        kwargs['size'] = NodeSize(id=size_id, name=None, ram=-1, disk=-1, bandwidth=-1,
                                  price=1.0, driver=self.conn, extra=None)
        kwargs['image'] =  NodeImage(id=image_id, name=None, driver=self.conn, extra=None)
        kwargs['name'] = none_check(name, "default_name")
        if node_temp.getLocationId() != None:
            kwargs['location'] = self._find_object_in(self.conn.list_locations(), node_temp.getLocationId())
        #check keyName
        key_name = node_temp.getKeyPair()
        if key_name == None and self.prop != None:
            key_name = self.prop.getProperty("key_name")
        if key_name:
            kwargs["ex_keyname"] = key_name
        #inspect 'authentication'
        #TODO: authentication pw or ssh_key
        auth = node_temp.getAuthentication()
        if auth != None:
            features = self.conn.features['create_node']
            if 'generates_password' or 'password' in features:
                from libcloud.compute.base import NodeAuthPassword
                kwargs['auth'] = NodeAuthPassword(auth)
            elif 'ssh_key' in features:
                from libcloud.compute.base import NodeAuthSSHKey
                kwargs['auth'] = NodeAuthSSHKey(auth)
            else:
                raise NotImplementedError(
                    'authentication not implemented for this driver')    
        return kwargs    
        
    def _load_creds(self, file_path):
        import os.path
        path = os.path.normpath(os.path.abspath(file_path))
        #if os.path.exists(path):
        import sys
        try:
            import secrets
        except ImportError:
            try:
                sys.path.append(os.path.dirname(path))
                import secrets
            except ImportError:
                raise ImportError("Couldn't import secrets.py from %s" % (path))
        provider_name = self.provider.upper()
        print(provider_name)
        args = getattr(secrets, provider_name + '_PARAMS', ())
        kwargs = getattr(secrets, provider_name + '_KEYWORD_PARAMS', {})
        return (args, kwargs)
        #else:
        #    raise ImportError("Invalid filepath: %s to secrets.py" % (path))
        
        
    def _find_object_in(self, listing, obj_id):
        res = [obj for obj in listing if obj.id == obj_id][0] if listing != None else None
        if res == None:
            raise AttributeError("no obj with id:%s found!" % (obj_id))
        else:
            return res
    
    def _list_sizes_cached(self):
        if self.size_cache == None:
                self.size_cache = self.conn.list_sizes()
        return self.size_cache
