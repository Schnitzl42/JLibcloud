====================================== =============== ============== ============ ============= ============= ===================
Provider                               create balancer list balancers list members attach member detach member attach compute node
====================================== =============== ============== ============ ============= ============= ===================
`Brightbox`_                           yes             yes            yes          yes           yes           yes                
`CloudStack`_                          yes             yes            yes          yes           yes           no                 
`Amazon Elastic Load Balancing`_       yes             yes            yes          no            yes           yes                
`Google Compute Engine Load Balancer`_ yes             yes            yes          yes           yes           yes                
`GoGrid LB`_                           yes             yes            yes          yes           yes           no                 
`Ninefold LB`_                         yes             yes            yes          yes           yes           no                 
`Rackspace LB`_                        yes             yes            yes          yes           yes           no                 
`Rackspace LB`_                        yes             yes            yes          yes           yes           no                 
`Rackspace LB`_                        yes             yes            yes          yes           yes           no                 
====================================== =============== ============== ============ ============= ============= ===================

.. _`Brightbox`: http://www.brightbox.co.uk/
.. _`CloudStack`: http://cloudstack.org/
.. _`Amazon Elastic Load Balancing`: http://aws.amazon.com/elasticloadbalancing/
.. _`Google Compute Engine Load Balancer`: https://cloud.google.com/
.. _`GoGrid LB`: http://www.gogrid.com/
.. _`Ninefold LB`: http://ninefold.com/
.. _`Rackspace LB`: http://www.rackspace.com/
.. _`Rackspace LB`: http://www.rackspace.com/
.. _`Rackspace LB`: http://www.rackspace.com/
