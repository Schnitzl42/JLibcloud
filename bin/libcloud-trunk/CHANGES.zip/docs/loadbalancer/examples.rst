:orphan:

LoadBalancer Examples
=====================

Create a Load Balancer with two members and wait for it to become ready
-----------------------------------------------------------------------

.. literalinclude:: /examples/loadbalancer/create_lb_wait_for_ready.py
   :language: python
