import libcloud.security as sec
sec.VERIFY_SSL_CERT = False
