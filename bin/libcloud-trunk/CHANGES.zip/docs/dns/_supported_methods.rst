===================== ========== ============ =========== =========== ============= ============= =========== =============
Provider              list zones list records create zone update zone create record update record delete zone delete record
===================== ========== ============ =========== =========== ============= ============= =========== =============
`Gandi DNS`_          yes        yes          yes         yes         yes           yes           yes         yes          
`Host Virtual DNS`_   yes        yes          yes         yes         yes           yes           yes         yes          
`Linode DNS`_         yes        yes          yes         yes         yes           yes           yes         yes          
`Rackspace DNS`_      yes        yes          yes         yes         yes           yes           yes         yes          
`Rackspace DNS (UK)`_ yes        yes          yes         yes         yes           yes           yes         yes          
`Rackspace DNS (US)`_ yes        yes          yes         yes         yes           yes           yes         yes          
`Route53 DNS`_        yes        yes          yes         no          yes           yes           yes         yes          
`Zerigo DNS`_         yes        yes          yes         yes         yes           yes           yes         yes          
===================== ========== ============ =========== =========== ============= ============= =========== =============

.. _`Gandi DNS`: http://www.gandi.net/domain
.. _`Host Virtual DNS`: http://www.vr.org/
.. _`Linode DNS`: http://www.linode.com/
.. _`Rackspace DNS`: http://www.rackspace.com/
.. _`Rackspace DNS (UK)`: http://www.rackspace.com/
.. _`Rackspace DNS (US)`: http://www.rackspace.com/
.. _`Route53 DNS`: http://aws.amazon.com/route53/
.. _`Zerigo DNS`: http://www.zerigo.com/
