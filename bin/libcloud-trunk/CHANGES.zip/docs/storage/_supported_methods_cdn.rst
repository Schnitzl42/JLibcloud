============================= ==================== ================= ===================== ==================
Provider                      enable container cdn enable object cdn get container cdn URL get object cdn URL
============================= ==================== ================= ===================== ==================
`Microsoft Azure (blobs)`_    no                   no                no                    no                
`CloudFiles`_                 yes                  no                yes                   yes               
`CloudFiles (UK)`_            yes                  no                yes                   yes               
`CloudFiles (US)`_            yes                  no                yes                   yes               
`Google Storage`_             no                   no                no                    no                
`KTUCloud Storage`_           yes                  no                yes                   yes               
`Nimbus.io`_                  no                   no                no                    no                
`Ninefold`_                   no                   yes               no                    yes               
`OpenStack Swift`_            yes                  no                yes                   yes               
`Amazon S3 (standard)`_       no                   no                no                    no                
`Amazon S3 (ap-northeast-1)`_ no                   no                no                    no                
`Amazon S3 (ap-southeast-1)`_ no                   no                no                    no                
`Amazon S3 (eu-west-1)`_      no                   no                no                    no                
`Amazon S3 (us-west-1)`_      no                   no                no                    no                
`Amazon S3 (us-west-2)`_      no                   no                no                    no                
============================= ==================== ================= ===================== ==================

.. _`Microsoft Azure (blobs)`: http://windows.azure.com/
.. _`CloudFiles`: http://www.rackspace.com/
.. _`CloudFiles (UK)`: http://www.rackspace.com/
.. _`CloudFiles (US)`: http://www.rackspace.com/
.. _`Google Storage`: http://cloud.google.com/
.. _`KTUCloud Storage`: http://www.rackspace.com/
.. _`Nimbus.io`: https://nimbus.io/
.. _`Ninefold`: http://ninefold.com/
.. _`OpenStack Swift`: http://www.rackspace.com/
.. _`Amazon S3 (standard)`: http://aws.amazon.com/s3/
.. _`Amazon S3 (ap-northeast-1)`: http://aws.amazon.com/s3/
.. _`Amazon S3 (ap-southeast-1)`: http://aws.amazon.com/s3/
.. _`Amazon S3 (eu-west-1)`: http://aws.amazon.com/s3/
.. _`Amazon S3 (us-west-1)`: http://aws.amazon.com/s3/
.. _`Amazon S3 (us-west-2)`: http://aws.amazon.com/s3/
