============================= =============== ============ ================ ================ ============= ======================= =============== ========================= =============
Provider                      list containers list objects create container delete container upload object streaming object upload download object streaming object download delete object
============================= =============== ============ ================ ================ ============= ======================= =============== ========================= =============
`Microsoft Azure (blobs)`_    yes             yes          yes              yes              yes           yes                     yes             yes                       yes          
`CloudFiles`_                 yes             yes          yes              yes              yes           yes                     yes             yes                       yes          
`CloudFiles (UK)`_            yes             yes          yes              yes              yes           yes                     yes             yes                       yes          
`CloudFiles (US)`_            yes             yes          yes              yes              yes           yes                     yes             yes                       yes          
`Google Storage`_             yes             yes          yes              yes              yes           yes                     yes             yes                       yes          
`KTUCloud Storage`_           yes             yes          yes              yes              yes           yes                     yes             yes                       yes          
`Nimbus.io`_                  yes             no           yes              no               no            no                      no              no                        no           
`Ninefold`_                   yes             yes          yes              yes              yes           yes                     yes             yes                       yes          
`OpenStack Swift`_            yes             yes          yes              yes              yes           yes                     yes             yes                       yes          
`Amazon S3 (standard)`_       yes             yes          yes              yes              yes           yes                     yes             yes                       yes          
`Amazon S3 (ap-northeast-1)`_ yes             yes          yes              yes              yes           yes                     yes             yes                       yes          
`Amazon S3 (ap-southeast-1)`_ yes             yes          yes              yes              yes           yes                     yes             yes                       yes          
`Amazon S3 (eu-west-1)`_      yes             yes          yes              yes              yes           yes                     yes             yes                       yes          
`Amazon S3 (us-west-1)`_      yes             yes          yes              yes              yes           yes                     yes             yes                       yes          
`Amazon S3 (us-west-2)`_      yes             yes          yes              yes              yes           yes                     yes             yes                       yes          
============================= =============== ============ ================ ================ ============= ======================= =============== ========================= =============

.. _`Microsoft Azure (blobs)`: http://windows.azure.com/
.. _`CloudFiles`: http://www.rackspace.com/
.. _`CloudFiles (UK)`: http://www.rackspace.com/
.. _`CloudFiles (US)`: http://www.rackspace.com/
.. _`Google Storage`: http://cloud.google.com/
.. _`KTUCloud Storage`: http://www.rackspace.com/
.. _`Nimbus.io`: https://nimbus.io/
.. _`Ninefold`: http://ninefold.com/
.. _`OpenStack Swift`: http://www.rackspace.com/
.. _`Amazon S3 (standard)`: http://aws.amazon.com/s3/
.. _`Amazon S3 (ap-northeast-1)`: http://aws.amazon.com/s3/
.. _`Amazon S3 (ap-southeast-1)`: http://aws.amazon.com/s3/
.. _`Amazon S3 (eu-west-1)`: http://aws.amazon.com/s3/
.. _`Amazon S3 (us-west-1)`: http://aws.amazon.com/s3/
.. _`Amazon S3 (us-west-2)`: http://aws.amazon.com/s3/
